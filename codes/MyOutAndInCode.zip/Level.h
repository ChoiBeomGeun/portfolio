/******************************************************************************/
/*!
\file   Level.h
\author ChoiBeomGeun

\par    email: o77151@gmail.com
\par    GAM150
\par    Out & In
\date   2017/06/15

Level header file


All content 2017 DigiPen (USA) Corporation, all rights reserved.

*/
/******************************************************************************/
#ifndef LEVEL1_H
#define LEVEL1_H



void SetCheck(void);
void Level1Load(void);
void Level1Init(void);
void Level1Update(float dt);
void Level1Shutdown(void);
void Level1Unload(void);
#endif // !LEVEL1_H