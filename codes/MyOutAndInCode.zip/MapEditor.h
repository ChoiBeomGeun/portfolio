/******************************************************************************/
/*!
\file   MapEditor.h
\author ChoiBeomGeun

\par    email: o77151@gmail.com
\par    GAM150
\par    Out & In
\date   2017/06/15

This is a map editor header file


All content 2017 DigiPen (USA) Corporation, all rights reserved.

*/
/******************************************************************************/
#ifndef GAMESTATE1_H
#define GAMESTATE1_H

#include "WEGameData.h"

void MapEditorLoad(void);
void MapEditorInit(void);
void MapEditorUpdate(float dt);
void MapEditorShutdown(void);
void MapEditorUnload(void);


#endif 