/******************************************************************************/
/*!
\file    MapObjectManager.h
\author ChoiBeomGeun

\par    email: o77151@gmail.com
\par    GAM150
\par    Out & In
\date   2017/06/15

This is a map editor objectmanager header file


All content 2017 DigiPen (USA) Corporation, all rights reserved.

*/
/******************************************************************************/
#ifndef OBJECTMANAGER_H
#define OBJECTMANAGER_H

#include "WEVec2.h"


struct MapEditorObject //!< Object's informations
{

  WEVec2   position;          //!< Object's position
  WEVec2   velocity;          //!< Object's velocity
  WEVec2	Arrow;			//!< Moving Wall's Scale
    WEVec2    scale;             //!< Object's scale
  float    rotation;          //!< Object's rotation
  	int ObjectStyle;      //!< Object's Style
  int      objectID;          //!< Object's ID
  int      texture;           //!< Object's texture
  unsigned color;             //!< Object's color
  float WallRotation; //!< Moving Wall Rotation
  bool Moving = false;
  bool deleteCheck = false;

};


/******************************************************************************/
/*!
  \class ObjectManager

    Operations include:

    - Allocate the objects and buttons.
    - Return objects, objectcount
    - Add the objects  to each array.
*/
/******************************************************************************/
class MapEditorObjectManager
{
public:

	MapEditorObjectManager(int maxObjects);
  ~MapEditorObjectManager(void);
  void MapEditorAddObjectCount(void);
  MapEditorObject* MapEditorGetObjects(void);
  int MapEditorGetObjectCount(void) const;

  void MapEditorAddObject(
    const WEVec2& pos,
    const WEVec2& Vel,
    float rotation,
    const WEVec2& scale,
    int texture,
    unsigned color,
	  int objectstyle,bool deletecheck);

  void MapEditorDownObjectCount(void);

private:
	MapEditorObject *MapEditorm_object;     //!< Array of Objects
  int MapEditorm_objectcount;    //!< Number of Objects

};


#endif /* OBJECTMANAGER_H */
