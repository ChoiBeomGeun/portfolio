
/******************************************************************************/
/*!
\file   MapEditor.cpp
\author ChoiBeomGeun

\par    email: o77151@gmail.com
\par    GAM150
\par    Out & In
\date   2017/06/15

This is a map editor for a Out & In game

All content 2017 DigiPen (USA) Corporation, all rights reserved.

*/
/******************************************************************************/
#include "MapEditor.h"

#include "WEDebugTools.h"
#include "WEApplication.h"
#include "WEStateManager.h"
#include "WEInput.h"
#include "WEGraphics.h"
#include "WEMath.h"
#include "WERandom.h"
#include "WEIntersection.h"
#include <stdio.h>
#include "MapObjectManager.h"
#include "GameType.h"
#include "Actions.h"




#include <cstdio> /*sprintf, fopen, fclose, FILE*/
void WriteObjectinformation(void);
bool ins = false;
bool nextins = false;
bool SavedCheck = false;
 int e_object = 0;
 int currentLevel = 1;
 float timecount = 0;
 namespace
 {
	int Squarecount=0;
	 int Spinecount=0;
	 int GravityZonecount=0;
	 int movingWallcount=0;
	 int BreakableWallcount=0;
	 char *levelstring1 = "Levels//level1.txt";
	 char *levelstring2 = "Levels//level2.txt";
	 char *levelstring3 = "Levels//level3.txt";
	 char *levelstring4 = "Levels//level4.txt";
	 char *levelstring5 = "Levels//level5.txt";
	 char *levelstring6 = "Levels//level6.txt";
	 char *levelstring7 = "Levels//level7.txt";
	 char *levelstring8 = "Levels//level8.txt";
	 char *levelstring9 = "Levels//level9.txt";
	 char *levelstring10 = "Levels//level10.txt";
	 char *levelstring11 = "Levels//level11.txt";
	 char *levelstring12 = "Levels//level12.txt";
	 char *levelstring13 = "Levels//level13.txt";
	 char *levelstring14 = "Levels//level14.txt";
	 char *levelstring15 = "Levels//level15.txt";
	 char *levelstring16 = "Levels//level16.txt";
	 char *levelstring17 = "Levels//level17.txt";
	 char *levelstring18 = "Levels//level18.txt";
	 char *levelstring19 = "Levels//level19.txt";
	 char *levelstring20 = "Levels//level20.txt";
	 char *levelstring21 = "Levels//level21.txt";
	 char *levelstring22 = "Levels//level22.txt";
	 char *levelstring23 = "Levels//level23.txt";
	 char *levelstring24 = "Levels//level24.txt";
	 char *levelstring25 = "Levels//level25.txt";
	 char *levelstring26 = "Levels//level26.txt";
	 char *levelstring27 = "Levels//level27.txt";
	 char *levelstring28 = "Levels//level28.txt";
	 char *levelstring29 = "Levels//level29.txt";
	 char *levelstring30 = "Levels//level30.txt";

	 char *LevelNumber;
	 int BackText;
	 float fwindowHeight;
	 float fwindowWidth;
	 bool Check = false;
	 bool Editmode = false;
	 bool Spawnmode = true;
	 bool EditCheck = false;
	 bool MovingWall = false;
	 Button Back;
	 Button Resize;
	 /*Color Info*/
	 enum Colors
	 {
		 C_NORMAL, /*0*/
		 C_RED,    /*1*/
		 C_BLUE,   /*2*/
		 C_BLACK,  /*3*/
		 C_COUNT   /*4*/
	 };


	 struct OMDemoData
	 {
		 enum ObjectType
		 {
			 Square,
			 Ball,
			 Cannon,
			 Spine,
			 CLEARZONE,
			 GravityUp,
			 GravityDown,
			 GravityZone,
			 Star,
			 MovingWall,
			 BreakableWall

		 };
		 unsigned colors[C_COUNT];
		 float movingWallAngle;
		 WEVec2 angleup;
		 float		Angle=0;
		 WEVec2 Arrow;
		 int ResizeID;
		 int		MovingWallID;
		 int		LeftID;
		 int		RightID;
		 int      SquareID;
		 int      CannonID;
		 int      BallID;
		 int		SpineID;
		 int		ClearZoneID;
		 int      EditUIID;
		 int      SpawnUIID;
		 int		StarID;
		 int		CannonTriID;
		 int SavedID;
		 int GravityArrowID;
		 int GravityZoneID;
		 int Ins0ID;
		 int Ins1ID;
		 int TABID;
		 int BreakableWallID;
		 bool Spawn = true;
		 bool CannonSpawn = false;
		 bool ClearZoneSpawn = false;
		 float Gravityangle =0 ;
		 //file data
		 bool ins = true;
		 bool delcheck =true;
		 int objCount= 1;
		 //Our object Manager 
		 MapEditorObjectManager* pObjMgr;
		
	 };
	
 }
 OMDemoData data;
 
/******************************************************************************/
/*!
Loading a previous level which was made before
*/
/******************************************************************************/
 void LoadingLevel(void)
 {
	 if (currentLevel == 1)
		 LevelNumber = levelstring1;
	 if (currentLevel == 2)
		 LevelNumber = levelstring2;
	 if (currentLevel == 3)
		 LevelNumber = levelstring3;
	 if (currentLevel == 4)
		 LevelNumber = levelstring4;
	 if (currentLevel == 5)
		 LevelNumber = levelstring5;
	 if (currentLevel == 6)
		 LevelNumber = levelstring6;
	 if (currentLevel == 7)
		 LevelNumber = levelstring7;
	 if (currentLevel == 8)
		 LevelNumber = levelstring8;
	 if (currentLevel == 9)
		 LevelNumber = levelstring9;
	 if (currentLevel == 10)
		 LevelNumber = levelstring10;
	 if (currentLevel == 11)
		 LevelNumber = levelstring11;
	 if (currentLevel == 12)
		 LevelNumber = levelstring12;
	 if (currentLevel == 13)
		 LevelNumber = levelstring13;
	 if (currentLevel == 14)
		 LevelNumber = levelstring14;
	 if (currentLevel == 15)
		 LevelNumber = levelstring15;
	 if (currentLevel == 16)
		 LevelNumber = levelstring16;
	 if (currentLevel == 17)
		 LevelNumber = levelstring17;
	 if (currentLevel == 18)
		 LevelNumber = levelstring18;
	 if (currentLevel == 19)
		 LevelNumber = levelstring19;
	 if (currentLevel == 20)
		 LevelNumber = levelstring20;
	 if (currentLevel == 21)
		 LevelNumber = levelstring21;
	 if (currentLevel == 22)
		 LevelNumber = levelstring22;
	 if (currentLevel == 23)
		 LevelNumber = levelstring23;
	 if (currentLevel == 24)
		 LevelNumber = levelstring24;
	 if (currentLevel == 25)
		 LevelNumber = levelstring25;
	 if (currentLevel == 26)
		 LevelNumber = levelstring26;
	 if (currentLevel == 27)
		 LevelNumber = levelstring27;
	 if (currentLevel == 28)
		 LevelNumber = levelstring28;
	 if (currentLevel == 29)
		 LevelNumber = levelstring29;
	 if (currentLevel == 30)
		 LevelNumber = levelstring30;

	 MapEditorObject obj;
	 obj.color = 0;
	 obj.deleteCheck = 0;
	 obj.Moving = 0;
	 obj.objectID = 0;
	 obj.ObjectStyle = 0;
	 obj.position.Set(0, 0);
	 obj.scale.Set(0, 0);
	 obj.rotation = 0;
	 obj.texture = 0;
	 obj.velocity.Set(0, 0);

	 FILE *fp=0;
	 fopen_s(&fp, LevelNumber, "rt");
	 fscanf_s(fp, "%d %d %d %d %d %d\n", &data.objCount, &data.objCount, &data.objCount
	 , &data.objCount, &data.objCount, &data.objCount);
	 for (int i = 0; i < data.objCount; i++)// Loop until the object count
	 {
		 ////////////////////////////////////Read Data from File and save the data to variables
		 fscanf_s(fp, "%f %f %f %f %f %u %d %d\n", &obj.position.x, &obj.position.y,
			 &obj.scale.x, &obj.scale.y,
			 &obj.rotation,
			 &obj.color,
			 &obj.ObjectStyle, &data.objCount);
		 if (obj.ObjectStyle == data.Square)
			 obj.texture = data.SquareID;
		 if (obj.ObjectStyle == data.Ball)
			 obj.texture = data.BallID;
		 if (obj.ObjectStyle == data.Cannon)
			 obj.texture = data.CannonID;
		 if (obj.ObjectStyle == data.CLEARZONE)
			 obj.texture = data.ClearZoneID;
		 if (obj.ObjectStyle == data.Star)
			 obj.texture = data.StarID;
		 if (obj.ObjectStyle == data.GravityUp ||obj.ObjectStyle == data.GravityZone||obj.ObjectStyle == data.GravityDown)
			 obj.texture = data.GravityZoneID;
		 if (obj.ObjectStyle == data.Spine)
			 obj.texture = data.SpineID;
		 if (obj.ObjectStyle == data.MovingWall)
			 obj.texture = data.MovingWallID;
		 if (obj.ObjectStyle == data.BreakableWall)
			 obj.texture = data.BreakableWallID;
		 data.pObjMgr->MapEditorAddObject(obj.position,obj.velocity,obj.rotation,obj.scale,obj.texture
		 ,obj.color,obj.ObjectStyle,obj.deleteCheck);

		 data.pObjMgr->MapEditorAddObjectCount();

	 }
	 fclose(fp);

	


 }
 /******************************************************************************/
 /*!
 Create a Object to MapEditorObjectManager
 */
 /******************************************************************************/
 
 void CreateObject(void)
{
	
		WEVec2 pos;
		WEVec2 vel;
		WEVec2 scale;
		WEVec2 mouse;
		WEInput::GetMouse(mouse);
		WEGraphics::ConvertScreenToWorld(mouse.x, mouse.y);
	  /////////// Init Object	
		pos.x = mouse.x;
		pos.y = mouse.y;
		vel.x = 0;
		vel.y = 0;
		scale.Set(4, 4);
		bool deletecheck = false;
		int objstyle = data.Square;
	  //////////
		/*Add to the object manager*/
		data.pObjMgr->MapEditorAddObject(pos, vel,
			0,
			scale,
			data.SquareID,
				data.colors[C_NORMAL],
			objstyle,deletecheck);
	
  }




void MapEditorLoad(void)
{ 
	WEGraphics::SetBackgroundColor(1.f, 1.f, 1.f);/*White background*/
	BackText = WEGraphics::LoadTexture("MapEditor//BackArrow.tga");
	data.ResizeID = WEGraphics::LoadTexture("MapEditor//resize.tga");
	data.SquareID = WEGraphics::LoadTexture("MapEditor//Base.tga");
	data.CannonID = WEGraphics::LoadTexture("MapEditor//Cannon.tga");
	data.BallID = WEGraphics::LoadTexture("MapEditor//Ball.tga");
	data.ClearZoneID = WEGraphics::LoadTexture("MapEditor//ClearZone.tga");
	data.SpineID = WEGraphics::LoadTexture("MapEditor//Spine.tga");
	data.SpawnUIID = WEGraphics::LoadTexture("MapEditor//spawnmode.tga");
	data.GravityArrowID = WEGraphics::LoadTexture("MapEditor//BackSign.tga");
	data.GravityZoneID = WEGraphics::LoadTexture("MapEditor//GravityZone.tga");
	data.EditUIID = WEGraphics::LoadTexture("MapEditor//editmode.tga");
	data.BreakableWallID = WEGraphics::LoadTexture("MapEditor//Wall0.tga");
	data.Ins0ID = WEGraphics::LoadTexture("MapEditor//ins0.tga");
		data.Ins1ID = WEGraphics::LoadTexture("MapEditor//ins1.tga");
		data.TABID = WEGraphics::LoadTexture("MapEditor//TAB.tga");	
		data.SavedID = WEGraphics::LoadTexture("MapEditor//LevelSaved.tga");
		data.StarID = WEGraphics::LoadTexture("MapEditor//star.tga");
		data.CannonTriID = WEGraphics::LoadTexture("MapEditor//CannonTri.tga");
		data.MovingWallID = WEGraphics::LoadTexture("MapEditor//ArrowRo.tga");
		data.LeftID = WEGraphics::LoadTexture("MapEditor//Left.tga");
		data.RightID = WEGraphics::LoadTexture("MapEditor//Right.tga");
	
		data.colors[C_NORMAL] = 0xFFFFFFFF; /*This is the regular texture color*/
	data.colors[C_RED] = 0xFF0000FF;
	data.colors[C_BLUE] = 0xFFFF0000;
	data.colors[C_BLACK] = 0xFF000000;

}


void MapEditorInit(void)
{
	
	fwindowHeight = (float)WEApplication::GetHeight();
	fwindowWidth = (float)WEApplication::GetWidth();
	data.pObjMgr = new MapEditorObjectManager(100);
	WEDEBUG_CREATE_CONSOLE();
	data.Arrow.Set(8, 32);
	data.angleup.Set(0, 0);
	Back.pos.x = fwindowWidth*.5f + 210;
	Back.pos.y = fwindowHeight - 129.f;
	Back.scale.x = 64.f;
	Back.scale.y = 64.f;
	Resize.pos.x = fwindowWidth*.5f -610;
	Resize.pos.y = fwindowHeight - 20.f;
	Resize.scale.x = 32.f;
	Resize.scale.y = 32.f;

	Back.action = ChangeToMenuAction;
	WEApplication::SetShowCursor(true);
}

void MapEditorUpdate(float dt)
{
	WEApplication::SetShowCursor(true);
	WEVec2 mouse;
	WEInput::GetMouse(mouse);
	if (WEInput::IsTriggered(WE_MOUSE_LEFT))
	{
		if (WEIntersection::PointRect(mouse, Back.pos, Back.scale.x, Back.scale.y))
		{
			if(data.ins)
			Back.action();
		}

		if (WEIntersection::PointRect(mouse, Resize.pos, Resize.scale.x, Resize.scale.y))
		{
			if (data.ins)
				data.ins = false;
			else
				data.ins = true;
		}




	}

	WEGraphics::SetCamera(0, 0, 60.f, 0);
	if (WEInput::IsTriggered(WE_F2))
	{


		MapEditorInit();
		LoadingLevel();
	}
;
	int object = data.pObjMgr->MapEditorGetObjectCount();

	
	WEGraphics::ConvertScreenToWorld(mouse.x, mouse.y);
	WEMtx44 transform;


	if (WEInput::IsTriggered(WE_SHIFT))
	{
		if (Spawnmode)
		{
			Spawnmode = false;
			Editmode = true;
		}
		else
		{
			Spawnmode = true;
			Editmode = false;
		}
	}

	//Get objects' information by MapEditorObjectManager
	MapEditorObject *pObjects = data.pObjMgr->MapEditorGetObjects();


	if (Editmode)
	{
		object = data.pObjMgr->MapEditorGetObjectCount();
		for (int i = 0; i < object; ++i)
		{
			if (WEInput::IsTriggered(WE_MOUSE_LEFT))
			{
				pObjects[i].color = data.colors[C_NORMAL];
				if (WEIntersection::PointRect(mouse, pObjects[i].position,
					pObjects[i].scale.x,
					pObjects[i].scale.y))
				{
					EditCheck = true;
					e_object = pObjects[i].objectID;
					pObjects[i].color = data.colors[C_RED];
					WEDEBUG_PRINT("Select Num: %d\n", e_object);

				}
			
			}

		}
		if (EditCheck)
		{
			if (WEInput::IsPressed(WE_ARROW_UP))
			{
				pObjects[e_object].position.y += 0.1f;
			}
			if (WEInput::IsPressed(WE_ARROW_DOWN))
			{
				pObjects[e_object].position.y -= 0.1f;
			}
			if (WEInput::IsPressed(WE_ARROW_LEFT))
			{
				pObjects[e_object].position.x -= 0.1f;
			}
			if (WEInput::IsPressed(WE_ARROW_RIGHT))
			{
				pObjects[e_object].position.x += 0.1f;
			}
			if (WEInput::IsTriggered(WE_BACKSPACE))
			{
				pObjects[e_object].scale.x = 0.f;
				pObjects[e_object].scale.y = 0.f;

			}
		}
	}

	if (Spawnmode)
	{
		if (WEInput::IsTriggered(WE_MOUSE_LEFT))
		{
			Check = true;
			data.Spawn = false;
			CreateObject();
		}
	}
	if (Check)
	{
		pObjects[object].position.x = mouse.x;
		pObjects[object].position.y = mouse.y;

		//**********************************************************
		// Select Objcet's type with 1,2,3,4,5
		// 1. Square
		// 2. Caanon
		// 3. ClearZone
		// 4. Spine
		// 5. GravityZone
		// 6. Star
		// 7. Moving Wall
		// 8. Breakable Wall
		if (WEInput::IsTriggered(WE_1))
		{

			pObjects[object].scale.Set(4, 4);
			pObjects[object].texture = data.SquareID;
			pObjects[object].ObjectStyle = data.Square;
			pObjects[object].Moving = false;
			pObjects[object].rotation = 0;
		}

		if (WEInput::IsTriggered(WE_2) && !(data.CannonSpawn) )
		{
			pObjects[object].scale.Set(15, 9);
			pObjects[object].rotation = 0;
			pObjects[object].texture = data.CannonID;
			pObjects[object].ObjectStyle = data.Cannon;
			pObjects[object].Moving = false;

		}
		if (WEInput::IsTriggered(WE_3) && !(data.ClearZoneSpawn))
		{
			pObjects[object].scale.Set(4, 4);
			pObjects[object].texture = data.ClearZoneID;
			pObjects[object].ObjectStyle = data.CLEARZONE;
			pObjects[object].Moving = false;
			pObjects[object].rotation = 0;
		}
		if (WEInput::IsTriggered(WE_4))
		{
			pObjects[object].scale.Set(4, 4);
			pObjects[object].texture = data.SpineID;
			pObjects[object].rotation = 0;
			pObjects[object].ObjectStyle = data.Spine;
			pObjects[object].Moving = false;
			//************************************************************
			//	  Adjust Object scale ,rotation
		}
		if (WEInput::IsTriggered(WE_5))
		{
			pObjects[object].scale.Set(4, 4);

			pObjects[object].texture = data.GravityZoneID;
			pObjects[object].Moving = false;
			pObjects[object].ObjectStyle = data.GravityZone;
			pObjects[object].rotation = 0;
		}
		if (WEInput::IsTriggered(WE_6))
		{
			pObjects[object].scale.Set(8, 8);

			pObjects[object].texture = data.StarID;
			pObjects[object].Moving = false;
			pObjects[object].ObjectStyle = data.Star;
			pObjects[object].rotation = 0;
		}

		if (WEInput::IsTriggered(WE_7))
		{
			pObjects[object].scale.Set(8, 8);

			pObjects[object].texture = data.SquareID;
			pObjects[object].ObjectStyle = data.Square;
			pObjects[object].Moving = true;
			pObjects[object].rotation = 0;
		}
		if (WEInput::IsTriggered(WE_8))
		{
			pObjects[object].scale.Set(8, 8);
		
			pObjects[object].texture = data.BreakableWallID;
			pObjects[object].ObjectStyle = data.BreakableWall;
			pObjects[object].Moving = false;
			pObjects[object].rotation = 0;
		}


		if (WEInput::IsTriggered(WE_P))
		{
			pObjects[object].rotation += (90);
			if ((pObjects[object]).rotation == 360)
			pObjects[object].rotation = 0;
			if (pObjects[object].ObjectStyle == data.GravityZone)
			{
				data.Gravityangle += (90);
				if (data.Gravityangle == 360)
					data.Gravityangle = 0;
				pObjects[object].rotation = data.Gravityangle;
			}
		}
		if (pObjects[object].ObjectStyle != data.Cannon &&pObjects[object].ObjectStyle != data.Ball)
		{
			if (WEInput::IsPressed(WE_ARROW_UP))
			{
				if (pObjects[object].ObjectStyle == data.MovingWall)
				{
					pObjects[object].scale.y += 0.4f;
		
				}
				if (pObjects[object].ObjectStyle == data.Ball)
				{
					pObjects[object].scale.x += 0.4f;
					pObjects[object].scale.y += 0.4f;
				}
				if (pObjects[object].ObjectStyle != data.Ball)
					pObjects[object].scale.y += 0.4f;
			}
			if (WEInput::IsPressed(WE_ARROW_DOWN))
			{
				if (pObjects[object].scale.y > 1 && pObjects[object].scale.x)
				{
					if (pObjects[object].ObjectStyle == data.MovingWall)
					{
						pObjects[object].scale.y -= 0.4f;
			
					}
					if (pObjects[object].ObjectStyle == data.Ball)
					{
						pObjects[object].scale.x -= 0.4f;
						pObjects[object].scale.y -= 0.4f;
					}
					if (pObjects[object].ObjectStyle != data.Ball)
						pObjects[object].scale.y -= 0.4f;
				}
			}
			if (WEInput::IsPressed(WE_ARROW_RIGHT))
			{
				if (pObjects[object].ObjectStyle == data.MovingWall)
				{
					pObjects[object].scale.x += 0.4f;
				
				}
				if (pObjects[object].ObjectStyle == data.Ball)
				{
					pObjects[object].scale.x += 0.4f;
					pObjects[object].scale.y += 0.4f;
				}
				if (pObjects[object].ObjectStyle != data.Ball)
					pObjects[object].scale.x += 0.4f;
			}
			if (pObjects[object].Moving)
			{
				if (WEInput::IsTriggered(WE_L))
				{
					pObjects[object].WallRotation += 45;

					if (pObjects[object].WallRotation > 360)
					{
						pObjects[object].WallRotation = 0;
					
					}

					
				}
				if (WEInput::IsTriggered(WE_K))
				{
					pObjects[object].Arrow.y += 1;
					data.Arrow.y += 1;


				}
			}

			if (WEInput::IsPressed(WE_ARROW_LEFT))
			{
				if (pObjects[object].ObjectStyle == data.MovingWall)
				{
					pObjects[object].scale.x -= 0.4f;

				}
				
				if (pObjects[object].scale.x > 1 && pObjects[object].scale.y)
				{
					if (pObjects[object].ObjectStyle == data.Ball)
					{
						pObjects[object].scale.x -= 0.4f;
						pObjects[object].scale.y -= 0.4f;
					}
					if (pObjects[object].ObjectStyle != data.Ball)
						pObjects[object].scale.x -= 0.4f;
				}
			}
			if (WEInput::IsPressed(WE_ARROW_UP) && WEInput::IsPressed(WE_CONTROL))
			{
				if (pObjects[object].ObjectStyle == data.Ball)
				{
					pObjects[object].scale.x += 4.f;
					pObjects[object].scale.y += 4.f;
				}
				if (pObjects[object].ObjectStyle != data.Ball)
					pObjects[object].scale.y += 4.f;
			}
			if (WEInput::IsPressed(WE_ARROW_DOWN) && WEInput::IsPressed(WE_CONTROL))
			{
				if (pObjects[object].scale.y > 1 && pObjects[object].scale.x)
				{
					if (pObjects[object].ObjectStyle == data.Ball)
					{
						pObjects[object].scale.x -= 4.f;
						pObjects[object].scale.y -= 4.f;
					}
					if (pObjects[object].ObjectStyle != data.Ball)
						pObjects[object].scale.y -= 4.f;
				}
			}
			if (WEInput::IsPressed(WE_ARROW_RIGHT) && WEInput::IsPressed(WE_CONTROL))
			{
				if (pObjects[object].ObjectStyle == data.Ball)
				{
					pObjects[object].scale.x += 4.f;
					pObjects[object].scale.y += 4.f;
				}
				if (pObjects[object].ObjectStyle != data.Ball)
					pObjects[object].scale.x += 4.f;
			}
			if (WEInput::IsPressed(WE_ARROW_LEFT) && WEInput::IsPressed(WE_CONTROL))
			{
				if (pObjects[object].scale.x > 1 && pObjects[object].scale.y)
				{
					if (pObjects[object].ObjectStyle == data.Ball)
					{
						pObjects[object].scale.x -= 4.f;
						pObjects[object].scale.y -= 4.f;
					}
					if (pObjects[object].ObjectStyle != data.Ball)
						pObjects[object].scale.x -= 4.f;
				}
			}
		}

		// Stick the object and indicate next object
		if (WEInput::IsTriggered(WE_MOUSE_RIGHT))
		{
			if (pObjects[object].ObjectStyle == data.Cannon)
				data.CannonSpawn = true;
			if (pObjects[object].ObjectStyle == data.CLEARZONE)
				data.ClearZoneSpawn = true;
			data.Spawn = true;
			Check = false;
			data.pObjMgr->MapEditorAddObjectCount();







			if (pObjects[object].Moving)
			{
				
				pObjects[data.pObjMgr->MapEditorGetObjectCount()].position = pObjects[object].position ;
				pObjects[data.pObjMgr->MapEditorGetObjectCount()].scale = pObjects[object].Arrow;
				pObjects[data.pObjMgr->MapEditorGetObjectCount()].ObjectStyle = data.MovingWall;
				pObjects[data.pObjMgr->MapEditorGetObjectCount()].rotation = pObjects[object].WallRotation;
				data.pObjMgr->MapEditorAddObjectCount();
			}
		}
	}

	WEGraphics::SetToPerspective();
	WEGraphics::StartDraw();
	WEMtx44 GravityArrow;
	WEMtx44 CannonTri;
	WEMtx44 ArrowRo;
  for (int i = 0; i <= data.pObjMgr->MapEditorGetObjectCount(); ++i)
  {
	  if (pObjects[i].Moving)
	  {
		  WEGraphics::SetTexture(data.MovingWallID);
		  WEGraphics::SetTextureColor(255, 255, 255, 255);
		  WEMtx44::MakeTransform(ArrowRo,
			  pObjects[i].Arrow.x, pObjects[i].Arrow.y,
			  WEMath::DegreeToRadian(pObjects[i].WallRotation),
			  pObjects[i].position.x + data.angleup.x, pObjects[i].position.y+data.angleup.y,-1.f);
		  WEGraphics::Draw(ArrowRo);
	  
	  }
	  if (!(pObjects[i].ObjectStyle == data.GravityZone))
	  {
		  WEGraphics::SetTexture(pObjects[i].texture);
		  WEGraphics::SetTextureColor(pObjects[i].color);
		  WEMtx44::MakeTransform(transform,
			  pObjects[i].scale.x, pObjects[i].scale.y,
			  WEMath::DegreeToRadian(pObjects[i].rotation),
			  pObjects[i].position.x, pObjects[i].position.y, 1.f);
		  WEGraphics::Draw(transform);
	  }
	  if(pObjects[i].ObjectStyle == data.GravityZone)
	  {
		  WEGraphics::SetTexture(data.GravityArrowID);
		  WEGraphics::SetTextureColor(255, 255, 255, 255);
		  WEMtx44::MakeTransform(GravityArrow,
			  8, 8,
			  WEMath::DegreeToRadian(pObjects[i].rotation),
			  pObjects[i].position.x, pObjects[i].position.y, 2.f);
		  WEGraphics::Draw(GravityArrow);



		  WEGraphics::SetTexture(pObjects[i].texture);
		  WEGraphics::SetTextureColor(pObjects[i].color);
		  WEMtx44::MakeTransform(transform,
			  pObjects[i].scale.x, pObjects[i].scale.y,
0,
			  pObjects[i].position.x, pObjects[i].position.y, 1.f);
		  WEGraphics::Draw(transform);
	  }
	  if (pObjects[i].ObjectStyle == data.Cannon)
	  {
		  WEGraphics::SetTexture(data.CannonTriID);
		  WEGraphics::SetTextureColor(255, 255, 255, 255);
		  WEMtx44::MakeTransform(CannonTri,
			  10, 5,
			  0,
			  pObjects[i].position.x, pObjects[i].position.y - 5, 2.f);
		  WEGraphics::Draw(CannonTri);

	  }
  }
  WEVec2 mouse1;
  WEInput::GetMouse(mouse1);
  WEGraphics::ConvertScreenToWorld(mouse1.x, mouse1.y);
  WEMtx44 Left;
  if (data.Spawn)
	  WEGraphics::SetTexture(data.LeftID);
  else
	  WEGraphics::SetTexture(data.RightID);

  WEGraphics::SetTextureColor(data.colors[C_NORMAL]);
  WEMtx44::MakeTransform(Left,
	  35, 35,
	  0,
	  mouse1.x+30, mouse1.y, 0.f);

  WEGraphics::Draw(Left);


  if (data.ins)
  {
	  WEMtx44 Status;
	  if (Spawnmode)
		  WEGraphics::SetTexture(data.SpawnUIID);
	  else
		  WEGraphics::SetTexture(data.EditUIID);

	  WEGraphics::SetTextureColor(data.colors[C_NORMAL]);
	  WEMtx44::MakeTransform(Status,
		  210.f, 45.f,
		  0,
		  0, 37.5, 0.f);

	  WEGraphics::Draw(Status);
  }

  // Save the information to the text file and exit
  if (WEInput::IsTriggered(WE_ESCAPE))
  { 

	  SavedCheck = true;
		    WriteObjectinformation();
	  ++currentLevel;
	  data.CannonSpawn = false;
	  data.ClearZoneSpawn = false;
	  MapEditorInit();	
  }
  if (WEInput::IsTriggered(WE_F1))
  {
	  WEStateManager::Quit();
  }
  if (data.ins)
  {
	  char testStr[100];
	  sprintf_s(testStr, "%d", currentLevel);
	  WEGraphics::SetTextureColor(0, 0, 0, 255);
	  WEGraphics::WriteText(testStr, -38.f, 38.f);
  }

  if (SavedCheck)
  {
		  WEMtx44 transform2;
		  WEGraphics::SetToOrtho();
		  WEGraphics::SetTexture(data.SavedID);
		  WEGraphics::SetTextureColor(data.colors[C_NORMAL]);
		  WEMtx44::MakeTransform(transform2,
			  450, 150,
			  0,
			  650, 400, 1.f);
		  WEGraphics::Draw(transform2);
		 
		  while (1)
		  {
				timecount +=  dt;
			  if (timecount >= 30.f)
			  {

				  SavedCheck = false;
				  break;

			  }
		  }
  }
  if (data.ins)
  {
	  WEMtx44 Back1;
	  WEGraphics::SetToOrtho();
	  WEGraphics::SetTexture(BackText);
	  WEGraphics::SetTextureColor(255, 255, 255, 255);
	  WEGraphics::SetTextureCoords(1.0f, 1.0f, 0.0f, 1.0f, 1.0f);
	  Back1.MakeTransform(Back1, Back.scale.x, Back.scale.y, 0.0f, Back.pos.x, Back.pos.y, 0.0f);
	  WEGraphics::Draw(Back1);
  }
  WEMtx44 Resize1;
  WEGraphics::SetToOrtho();
  WEGraphics::SetTexture(data.ResizeID);
  WEGraphics::SetTextureColor(255, 255, 255, 255);
  WEGraphics::SetTextureCoords(1.0f, 1.0f, 0.0f, 1.0f, 1.0f);
  
  Resize1.MakeTransform(Resize1, Resize.scale.x, Resize.scale.y, 0.0f, Resize.pos.x, Resize.pos.y, 0.0f);
  WEGraphics::Draw(Resize1);

  WEGraphics::EndDraw();/*We must call this after all drawing*/

}

/******************************************************************************/
/*!
This function is to save object information in the text file
----------Save Data List----------
-Postiion
-Scale
-Rotation
-Color
-ObjectStyle
-each Objectcount
*/
/******************************************************************************/

void WriteObjectinformation(void)
{
	



	int count = data.pObjMgr->MapEditorGetObjectCount();
	int i = 0;
	MapEditorObject * pObject = data.pObjMgr->MapEditorGetObjects();
	if (count > 3)
	{
		for (int j = 0; j< count; j++)
		{
			switch (pObject[j].ObjectStyle)
			{
			case data.Square:
				Squarecount++;
				break;
			case data.Spine:
				Spinecount++;
				break;
			case data.MovingWall:
				movingWallcount++;
				Squarecount++;
				break;
			case data.BreakableWall:
				BreakableWallcount++;
				break;
			case data.GravityZone:
				GravityZonecount++;
				break;
			}
		}
	}
	if(true)
	{
	if (currentLevel == 1)
		LevelNumber = levelstring1;
	if (currentLevel == 2)
		LevelNumber = levelstring2;
	if (currentLevel == 3)
		LevelNumber = levelstring3;
	if (currentLevel == 4)
		LevelNumber = levelstring4;
	if (currentLevel == 5)
		LevelNumber = levelstring5;
	if (currentLevel == 6)
		LevelNumber = levelstring6;
	if (currentLevel == 7)
		LevelNumber = levelstring7;
	if (currentLevel == 8)
		LevelNumber = levelstring8;
	if (currentLevel == 9)
		LevelNumber = levelstring9;
	if (currentLevel == 10)
		LevelNumber = levelstring10;
	if (currentLevel == 11)
		LevelNumber = levelstring11;
	if (currentLevel == 12)
		LevelNumber = levelstring12;
	if (currentLevel == 13)
		LevelNumber = levelstring13;
	if (currentLevel == 14)
		LevelNumber = levelstring14;
	if (currentLevel == 15)
		LevelNumber = levelstring15;
	if (currentLevel == 16)
		LevelNumber = levelstring16;
	if (currentLevel == 17)
		LevelNumber = levelstring17;
	if (currentLevel == 18)
		LevelNumber = levelstring18;
	if (currentLevel == 19)
		LevelNumber = levelstring19;
	if (currentLevel == 20)
		LevelNumber = levelstring20;
	if (currentLevel == 21)
		LevelNumber = levelstring21;
	if (currentLevel == 22)
		LevelNumber = levelstring22;
	if (currentLevel == 23)
		LevelNumber = levelstring23;
	if (currentLevel == 24)
		LevelNumber = levelstring24;
	if (currentLevel == 25)
		LevelNumber = levelstring25;
	if (currentLevel == 26)
		LevelNumber = levelstring26;
	if (currentLevel == 27)
		LevelNumber = levelstring27;
	if (currentLevel == 28)
		LevelNumber = levelstring28;
	if (currentLevel == 29)
		LevelNumber = levelstring29;
	if (currentLevel == 30)
		LevelNumber = levelstring30;

}
	if (count > 3) // There are more than 3 objects , it will be saved 
	{
		FILE* pFile = 0;
		fopen_s(&pFile, LevelNumber, "wt");
		fprintf(pFile, "%d %d %d %d %d %d\n",Squarecount,Spinecount,GravityZonecount,movingWallcount,BreakableWallcount, count);
		for (; i < count; i++)
		{
			fprintf(pFile, "%f ", pObject[i].position.x);
			fprintf(pFile, "%f ", pObject[i].position.y);
			fprintf(pFile, "%f ", pObject[i].scale.x);
			fprintf(pFile, "%f ", pObject[i].scale.y);
			fprintf(pFile, "%f ", pObject[i].rotation);
			fprintf(pFile, "%u ", pObject[i].color);
			fprintf(pFile, "%d ", pObject[i].ObjectStyle);
			fprintf(pFile, "%d\n", count);
		
		}

		fclose(pFile);
	}
}

/******************************************************************************/
/*!
Clear the MapEditorObjectManager pointer
*/
/******************************************************************************/
void MapEditorShutdown(void)
{
	currentLevel = 1;
  delete data.pObjMgr;
  data.pObjMgr = 0;
}
/******************************************************************************/
/*!
Unload my textures
*/
/******************************************************************************/
void MapEditorUnload(void)
{
  WEGraphics::UnloadTexture(data.SquareID);
  WEGraphics::UnloadTexture(data.CannonID);
  WEGraphics::UnloadTexture(data.BallID);
    WEGraphics::UnloadTexture(data.ClearZoneID);
     WEGraphics::UnloadTexture(data.SpineID); 
	 WEGraphics::UnloadTexture(data.EditUIID);
	 WEGraphics::UnloadTexture(data.SpawnUIID);
	 WEGraphics::UnloadTexture(data.GravityArrowID);
	 WEGraphics::UnloadTexture(data.GravityZoneID);
	 WEGraphics::UnloadTexture(data.Ins0ID);
	 WEGraphics::UnloadTexture(data.Ins1ID);
	 WEGraphics::UnloadTexture(data.TABID);
	 WEGraphics::UnloadTexture(data.SavedID);
	 WEGraphics::UnloadTexture(data.StarID);
	 WEGraphics::UnloadTexture(data.CannonTriID);
	 WEGraphics::UnloadTexture(data.MovingWallID);
	 WEGraphics::UnloadTexture(BackText);
	 WEGraphics::UnloadTexture(data.BreakableWallID);
	 WEGraphics::UnloadTexture(data.LeftID);
	 WEGraphics::UnloadTexture(data.RightID);
	 WEGraphics::UnloadTexture(data.ResizeID);
}
