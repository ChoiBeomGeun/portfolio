/******************************************************************************/
/*!
\file   MapObjectManager.cpp
\author ChoiBeomGeun

\par    email: o77151@gmail.com
\par    GAM150
\par    Out & In
\date   2017/06/15

This is a map editor object Manager for a Out & In game


All content 2017 DigiPen (USA) Corporation, all rights reserved.

*/
/******************************************************************************/
#include "MapObjectManager.h"
#include "WEDebugTools.h"


/******************************************************************************/
/*!

  \brief
    Constructor of class ObjectManager.

  \param maxObjects
    An integer that max number of Objects.

*/
/******************************************************************************/
MapEditorObjectManager::MapEditorObjectManager(int maxObjects)
{
	
	MapEditorm_object = new MapEditorObject[maxObjects];

	for (int i = 0; i < maxObjects;++i)
	{
		MapEditorm_object[i].objectID = 0;
		MapEditorm_object[i].position.x = 0;
		MapEditorm_object[i].position.y = 0;
		MapEditorm_object[i].scale.x = 0;
		MapEditorm_object[i].scale.y = 0;
		MapEditorm_object[i].WallRotation = 0;
		MapEditorm_object[i].Arrow.Set(8, 32);
	}

	MapEditorm_objectcount = 0;

}

/******************************************************************************/
/*!

  \brief
    Destructor of class ObjectManager.

*/
/******************************************************************************/

MapEditorObjectManager::~MapEditorObjectManager(void)
{
	delete []MapEditorm_object;

}
/******************************************************************************/
/*!

  \brief
    Gettor function that returns the private variables of class ObjectManager.

  \return m_object

*/
/******************************************************************************/

MapEditorObject * MapEditorObjectManager::MapEditorGetObjects(void)
{
	return MapEditorm_object;
}
/******************************************************************************/
/*!

  \brief
    Gettor function that returns the private variables of class ObjectManager.

  \return m_objectcount

*/
/******************************************************************************/
int MapEditorObjectManager::MapEditorGetObjectCount(void) const
{
	
	return MapEditorm_objectcount;
}




/******************************************************************************/
/*!

  Take the object's information from the parameter and save it to the
  Object array.

  \param pos
    A position of object

  \param Vel
    A velocity of object

   \param rotation
    A floating number of object's rotation.

   \param scale
    A floating number of object's scale.

   \param texture
    An integer that determine the object's texture.

   \param color
    An unsigned integer that object's color.

   \param ObjectStyle
   Object's Style - Square , Ball, Cannon , Clear Zone, Spine , Gravity Zone, Breakable wall , MovingWall

   \param Deletecheck
   Checking Delete State

*/
/******************************************************************************/
void MapEditorObjectManager::MapEditorAddObject(const WEVec2 & pos, const WEVec2 & Vel, float rotation, const WEVec2 & scale, int texture, unsigned color, int objectstyle,bool Deletecheck)
{

	MapEditorm_object[MapEditorm_objectcount].objectID = MapEditorm_objectcount;
	MapEditorm_object[MapEditorm_objectcount].position = pos;
	MapEditorm_object[MapEditorm_objectcount].velocity = Vel;
	MapEditorm_object[MapEditorm_objectcount].rotation = rotation;
	MapEditorm_object[MapEditorm_objectcount].scale = scale;
	MapEditorm_object[MapEditorm_objectcount].texture = texture;
	MapEditorm_object[MapEditorm_objectcount].color = color;
	MapEditorm_object[MapEditorm_objectcount].ObjectStyle = objectstyle;
	MapEditorm_object[MapEditorm_objectcount].deleteCheck = Deletecheck;

}

//////////////Add ObjectCount
void MapEditorObjectManager::MapEditorAddObjectCount(void)
{
	++MapEditorm_objectcount;
}
/////////// Down Object Count
void MapEditorObjectManager::MapEditorDownObjectCount(void)
{
	--MapEditorm_objectcount;
}












