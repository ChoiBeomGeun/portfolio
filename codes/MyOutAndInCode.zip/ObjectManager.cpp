/******************************************************************************/
/*!
\file   ObjectManager.cpp
\author Beom Geun
\par    email: o77151@gmail.com
\par    GAM150
\par    Out & In 
\date   2017/04/07
\brief
This is the objectmanager file for GAM150 Out & in.

All content 2017 DigiPen (USA) Corporation, all rights reserved.
*/
/******************************************************************************/
#include "ObjectManager.h"
#include "WEDebugTools.h"
#include <memory>

/******************************************************************************/
/*!
  \brief
    Constructor of class ObjectManager.

  \param maxObjects
    An integer that max number of Objects.
*/
/******************************************************************************/
ObjectManager::ObjectManager(int maxObjects)
{
	m_object = new Object[maxObjects];
	m_maxObjects = maxObjects;
	m_objectcount = 0;
	memset(m_object, 0, sizeof(Object)*maxObjects);
	m_object->vecPos.Set(3000, 3000);
}

/******************************************************************************/
/*!
  \brief
    Destructor of class ObjectManager.
*/
/******************************************************************************/
ObjectManager::~ObjectManager(void)
{
	delete[]m_object;
}
/******************************************************************************/
/*!
  \brief
    Gettor function that returns the private variables of class ObjectManager.

  \return m_object
*/
/******************************************************************************/
Object* ObjectManager::GetObjects(void)
{
	return m_object;
}
/******************************************************************************/
/*!
  \brief
    Gettor function that returns the private variables of class ObjectManager.

  \return m_objectcount
*/
/******************************************************************************/
int ObjectManager::GetObjectCount(void) const
{
	return m_objectcount;
}
/******************************************************************************/
/*!
  Take the object's information from the parameter and save it to the
  Object array.

  \param pos
    A position of object

  \param Vel
    A velocity of object

   \param rotation
    A floating number of object's rotation.

   \param scale
    A floating number of object's scale.

   \param texture
    An integer that determine the object's texture.

   \param color
    An unsigned integer that object's color.

   \param ObjectStyle
   Object's Style - Square , Ball, Cannon , Clear Zone, Spine

*/
/******************************************************************************/
void ObjectManager::AddObject(WEVec2 Pos, WEVec2 Scale,
float rotation, int texture, int ObjectStyle,unsigned color
	, WEVec2 wVel,
WEVec2 vecRef,
WEVec2 vecGravityChang,
WEVec2 vecAngle,
float fP,
float fC,
float fPower,
float fDegree,
float fCosVal,
float fSinVaL, WEVec2 vecForce, int emitterID){
	
	m_object[m_objectcount].objectID = m_objectcount;
	m_object[m_objectcount].emitterID = emitterID;
	m_object[m_objectcount].vecPos = Pos;
	m_object[m_objectcount].vecScale= Scale;
	m_object[m_objectcount].rotation = rotation;
	m_object[m_objectcount].texture = texture;
	m_object[m_objectcount].color = color;
	m_object[m_objectcount].ObjectStyle = ObjectStyle;

	//////////////////////////// For Physiscs
	m_object[m_objectcount].vecForce = vecForce;
	m_object[m_objectcount].wVel = wVel;
	m_object[m_objectcount].vecRef = vecRef;
	m_object[m_objectcount].vecGravityChang = vecGravityChang;
	m_object[m_objectcount].vecAngle = vecAngle;
	m_object[m_objectcount].fP = fP; // needs to change its name I don't know what this is doing here. 
	m_object[m_objectcount].fC = fC;
	m_object[m_objectcount].fPower = fPower;
	m_object[m_objectcount].fDegree = fDegree;
	m_object[m_objectcount].fCosVal= fCosVal;
	m_object[m_objectcount].fSinVal = fSinVaL;
	++m_objectcount;
}