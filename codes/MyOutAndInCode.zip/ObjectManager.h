/******************************************************************************/
/*!
\file   ObjectManager.h
\author Beom Geun
\par    email: o77151@gmail.com
\par    GAM150
\par    Out & In
\date   2017/04/07
\brief
This is the objectmanager header file for GAM150 Out & in.

All content 2017 DigiPen (USA) Corporation, all rights reserved.
*/
/******************************************************************************/
#ifndef OBJECTMANAGER_H
#define OBJECTMANAGER_H

#include "WEVec2.h"


struct Object //!< Object's informations
{
	int ObjectStyle; //!<Object's style
	WEVec2 vecPos;//!<Object's Position
	WEVec2 vecScale;//!<Object's Scale
  float    rotation;          //!< Object's rotation  
  int      objectID;          //!< Object's ID
  int      texture;           //!< Object's texture
  unsigned color;             //!< Object's color
  bool Moving = false;
  int Movingnum ;
  ////////////For the physics
  WEVec2 wVel;
  WEVec2 vecRef;
  WEVec2 vecGravityChang;
  WEVec2 vecAngle;
  WEVec2 vecForce;
  float fP;
  float fC;
  float fPower;
  float fDegree;
  float fCosVal;
  float fSinVal;
  int emitterID;
};

class ObjectManager
{
public:
  ObjectManager(int maxObjects);
  ~ObjectManager(void);

  Object* GetObjects(void);

  int GetObjectCount(void) const;

  void AddObject(
  WEVec2 pos,
	  WEVec2 scale,
	  float rotation,
    int texture, int ObjectStyle,
    unsigned color,WEVec2 wVel,
	  WEVec2 vecRef,
	  WEVec2 vecGravityChang,
	  WEVec2 vecAngle,
	  float fP,
	  float fC,
	  float fPower,
	  float fDegree,
	  float fCosVal,
	  float fSinVa,WEVec2 vecForce, int emitterID);
private:

  Object *m_object;     //!< Array of Objects
  int m_objectcount;    //!< Number of Objects
  
  int m_maxObjects;     //!< maximum of Objects
};
#endif /* OBJECTMANAGER_H */