/******************************************************************************/
/*!
\file   Level.cpp
\author ChoiBeomGeun

\par    email: o77151@gmail.com
\par    GAM150
\par    Out & In
\date   2017/06/15

This is a whole Level. 
Applying Text file into Level
Applying all physics and collision into objects

All content 2017 DigiPen (USA) Corporation, all rights reserved.
*/
/******************************************************************************/
#include "WEDebugTools.h"
#include "WEApplication.h"
#include "WERandom.h"
#include "WEInput.h"
#include "WEGraphics.h"
#include "WEMath.h"
#include "WEIntersection.h"
#include"WEStateManager.h"
#include "..//WarpDemo/Source/ObjectManager.h"
#include "Level.h"
#include "HUD.h"
#include <cstdio> /*sprintf, fopen, fclose, FILE*/
#include <fstream>
#include "GameType.h"
#include "Actions.h"
#include "Physics.h"
#include "Collision.h"
#include "Shoot.h"
#include "DemoStates.h"
#include "Lose.h"
#include "Sound.h"
#include "PauseHUD.h"
#include "Win.h"
#include "LoseHUD.h"
#include <string>
#include "Ending.h"
//#include <stdio.h>

#define WE_MAX_TIME 3
#define LEVEL_MAX 15
#define WINDOW_X 160
#define WINDOW_Y 80

using namespace std;
extern bool Shoots = true;
extern bool pathT = true;
extern int Firststart = 1;
extern int LevelSelect = 0;
extern int ClearLevel = 0;
extern int LevelState=0;
extern int ScoreCount = 0;
extern int GetStar[30];
void F_levelSelect(int Level);


namespace{
	std::string path = getenv("USERPROFILE");
	Object* SquareObj;
	Object* BallObj;
	Object* CannonObj;
	Object* GravityZoneObj;
	Object* StarObj;
	Object* SpineObj;
	Object* MovingWallObj;
	Object* BreakableWallObj;

	int Squarecount=0;
	int Spinecount=0;
	int GravityZonecount=0;
	int movingWallcount=0;
	int BreakableWallcount=0;
	int backgroundTex;
	bool input = true;
	const float Clear_Speed = 5.f;
	int MovingWallnum = 0;
	bool mcheck = true;
	bool m2check = true;
	bool m3check = true;
	bool m4check = true;
	SoundSystemClass sound;	
	std::string LevelName;
	int UpArrowTex;
	int DownArrowTex;
	int SpaceBarTex;
	int ResetBarTex;
	int	StageLevelTex;
	int StageLevelTex2;
	int StageLevelTex3;
	int ReflectAni;
	bool isMusicOn = false;
	bool isPlaying;
	float timecount;
	float timecount1;
	float totaltime;
	float texturecoord;
	float texturecoord2;
	float texturecoord3;
	float texturecoord4;
	float texturecoord5;
	const int ARROWS_X = 256;
	const int ARROWS_Y = 256;
	const float LEVEL_X = 204.8f;
	const float LEVEL_Y = 128.f;
	const int SPACE_X = 1024;
	const int SPACE_Y = 256;
	int LevelStage;

	int ReadText(FILE * fp, const char* file)
	{

		fp = fopen(file, "rt"); // Load the Level text File
		return 5;
	}
}
namespace Camera{
	float cameraX;
	float cameraY;
	float cameraZ;
	float cameraRot;
	float viewTimer;


}


struct GameData{
	const int BUTTON_SCALEX = 128;
	const int BUTTON_SCALEY = 128;
	//bool Mousecursor = false;
	enum ObjectType{ Square, Ball, Cannon, Spine, ClearZone, GravityUp,
		GravityDown, GravityZone, Star,	MovingWall,	BreakableWall };
	int ins0ID;
	int ins1ID;
	int BallID;
	int CannonID;
	int SquareID;
	int	maxObjects ;
	int	objCount;
	int ClearZoneID;
	int SpineID;
	int CannonTriID;
	int StarID;

	int BreakableWall0;
	int BreakableWall1;
	int BreakableWall2;
	bool Check;
	bool WinCheck;
	bool LoseCheck;
	bool PreventR;
	int GravityArrowID;
	int GravityZoneID;
	int FullcannonID;
	bool SpineCheck;
	bool SpacePressCheck;
	bool OutOfWindow;
	int UpID;
	int DownID;
	int SpaceID;

	int FianlBack;
	int	BackSignTexture;
	WEVec2 topLeft;
	WEVec2 botRight;
	int earth;
	// size of the screen
	float	fwindowHeight;
	float	fwindowWidth;
	float	fcameraRot;

	//Our object Manager 
	ObjectManager* SquareMgr;
	ObjectManager* BallMgr;
	ObjectManager* CannonMgr;
	ObjectManager* GravityzoneMgr;	
	ObjectManager* StarMgr;
	ObjectManager* MovingWallMgr;
	ObjectManager* SpineMgr;
	ObjectManager * BreakWallMgr;

	Object ClearZoneObj;
	Button button[LEVEL_MAX];
	int trailCount;
	int explosionCount;
	WEVec2 botLeft;
};
GameData data1;

/*int ReadText(FILE * fp, const char* file)
{

	fp = fopen(file, "rt"); // Load the Level text File
	return 5;
}*/

void SetCheck(void){
	data1.Check = false;
}
void Change(void)
{

	if(pathT)
	path += "/Documents/OutandIn/";
	pathT = false;

}
void Level1Load(void){

	WEGraphics::SetBackgroundColor(0, 0, 0	);
	EndingHeader::EndingLoad();
	// Load Textures
	data1.BallID = WEGraphics::LoadTexture("Textures//Ball.tga");
	data1.CannonID = WEGraphics::LoadTexture("Textures//Cannon.tga");
	data1.SquareID = WEGraphics::LoadTexture("Textures//Base.tga");
	data1.BackSignTexture = WEGraphics::LoadTexture("Textures//BackSign.tga");
	data1.ClearZoneID = WEGraphics::LoadTexture("Textures//ClearZone.tga");
	data1.SpineID = WEGraphics::LoadTexture("Textures//Spine.tga");
	data1.CannonTriID = WEGraphics::LoadTexture("Textures//CannonTri.tga");
	data1.FullcannonID = WEGraphics::LoadTexture("Textures//FULLcannon.tga");
	data1.GravityZoneID = WEGraphics::LoadTexture("Textures//GravityZone.tga");
	data1.StarID = WEGraphics::LoadTexture("Textures//star.tga");
	data1.SpaceID = WEGraphics::LoadTexture("Textures//c4.tga");
	data1.UpID = WEGraphics::LoadTexture("Textures//c1.tga");
	data1.DownID = WEGraphics::LoadTexture("Textures//c2.tga");
	data1.ins0ID = WEGraphics::LoadTexture("Textures//ins.tga");
	data1.ins1ID = WEGraphics::LoadTexture("Textures//ins1.tga");
	data1.earth = WEGraphics::LoadTexture("Textures//earth.tga");
	UpArrowTex = WEGraphics::LoadTexture("Textures//c1.tga");
	DownArrowTex = WEGraphics::LoadTexture("Textures//c2.tga");
	SpaceBarTex = WEGraphics::LoadTexture("Textures//c4.tga");
	ResetBarTex = WEGraphics::LoadTexture("Textures//c3.tga");
	backgroundTex = WEGraphics::LoadTexture("Textures//background.tga");
	StageLevelTex = WEGraphics::LoadTexture("Textures//Level1.1_10.tga");
	StageLevelTex2 = WEGraphics::LoadTexture("Textures//Level2.1_10.tga");
	StageLevelTex3 = WEGraphics::LoadTexture("Textures//Level3.1_10.tga");
	data1.BreakableWall0 = WEGraphics::LoadTexture("Textures//wall0.tga");
	data1.BreakableWall1 = WEGraphics::LoadTexture("Textures//wall1.tga");
	data1.BreakableWall2 = WEGraphics::LoadTexture("Textures//wall2.tga");
	data1.FianlBack = WEGraphics::LoadTexture("Textures//FinalBackGround.tga");

	ReflectAni = WEGraphics::LoadTexture("Textures//again.tga");
	texturecoord = 0.0f;
	texturecoord2 = 0.0f;
	texturecoord3 = 0.0f;
	texturecoord4 = 0.0f;
	texturecoord5 = 0.0f;
	totaltime = 0.f;
	timecount = 0.f;
	timecount1 = 0.f;
	HUDHeader::HUDLoad();
	WEGraphics::GetWorldBotLeft(data1.botLeft);
	if (data1.Check == false)
		PauseHUDHeader::PauseHUDLoad();

	WinHeader::WinLoad();
	LoseHUDHeader::LoseHUDLoad();
	sound.createSound(SOUNDLIST::BOUNCING);
	sound.createSound(SOUNDLIST::RELOADING);
	sound.createSound(SOUNDLIST::SHOOT);
	sound.createSound(SOUNDLIST::STAR);
	sound.createSound(SOUNDLIST::LEVEL1);
	sound.createSound(SOUNDLIST::LOSE);

	WEGraphics::GetWorldBotLeft(data1.botLeft);
	WEDebug::CreateConsole();
	WEGraphics::SetToOrtho();
}


/******************************************************************************/
/*!
\brief
Add all objects from the text file as the level.


*/
/******************************************************************************/
void Level1Init(){
	Change();
	WEApplication::SetShowCursor(true);
	EndingHeader::EndingInit();
	F_levelSelect(LevelSelect);
	// Get WindowData
	data1.fwindowHeight = (float)WEApplication::GetHeight();
	data1.fwindowWidth = (float)WEApplication::GetWidth();
	// Set Camera
	WEGraphics::SetCamera(0, 0, 60, 0);
	// Get World Data
	Camera::viewTimer = WE_MAX_TIME + 1;


	// Init Button
	for (int i = 0; i < LEVEL_MAX; ++i)
	{
		data1.button[i].pos.x = (float)data1.BUTTON_SCALEX;
		data1.button[i].pos.y = (float)(data1.fwindowHeight - data1.BUTTON_SCALEY *.5f);
		data1.button[i].scale.x = (float)data1.BUTTON_SCALEX*.5f;
		data1.button[i].scale.y = (float)data1.BUTTON_SCALEY*.5f;
		data1.button[i].texPos.x = .1f*i;
		data1.button[i].texPos.y = 0;
		data1.button[i].action = ChangeToMenuAction;
	}
//	int fsdfsdf = 0;
	FILE *fp;
	//const char* df = LevelName.c_str();

//	fsdfsdf = ReadText(fp, LevelName.c_str());
	fopen_s(&fp, LevelName.c_str(), "rt"); // Load the Level text File
	fscanf_s(fp, "%d %d %d %d %d %d\n", &Squarecount, &Spinecount, &GravityZonecount, 
		&movingWallcount, &BreakableWallcount, &data1.objCount);
	if (GravityZonecount == 0)
		GravityZonecount = 1;
	if (movingWallcount == 0)
		movingWallcount = 1;
	if (BreakableWallcount == 0)
		BreakableWallcount = 1;
	if (Spinecount == 0)
		Spinecount = 1;

	data1.SquareMgr = new ObjectManager(Squarecount);
	data1.BallMgr = new ObjectManager(1);
	data1.CannonMgr = new ObjectManager(1);
	data1.GravityzoneMgr = new ObjectManager(GravityZonecount);
	data1.StarMgr = new ObjectManager(30);
	data1.MovingWallMgr = new ObjectManager(movingWallcount);
	data1.BreakWallMgr = new ObjectManager(BreakableWallcount);
	data1.SpineMgr = new ObjectManager(Spinecount);

	//////////////////////////////////// Init the object
	Object obj;
	obj.wVel.Set(0, 0);
	obj.vecRef.Set(0, 0);
	obj.vecGravityChang.Set(0, 0);
	obj.vecAngle.Set(0, 0);
	obj.fP = 0;
	obj.fC = 0;
	obj.color = 0;
	obj.Movingnum = 0;
	obj.Moving = 0;
	obj.objectID = 0;
	obj.ObjectStyle = 0;
	obj.rotation = 0.0f;
	obj.texture = 0;
	obj.vecPos.Set(3000,3000);
	obj.vecScale.Set(0, 0);
	obj.vecForce.Set(0, 0);
	obj.fPower = 0;
	obj.fDegree = 0.f;
	obj.fCosVal = 0;
	obj.fSinVal = 0;
	obj.vecForce.Set(0, 0);
	data1.ClearZoneObj.vecPos.Set(3000,3000); //Init the Clearzone Position
	data1.ClearZoneObj.vecScale.Set(0, 0);
	data1.trailCount = 500;

	for (int i = 0; i < data1.objCount; i++)// Loop until the object count
	{
		////////////////////////////////////Read Data from File and save the data to variables
		fscanf_s(fp, "%f %f %f %f %f %u %d %d\n", &obj.vecPos.x, &obj.vecPos.y, 
			&obj.vecScale.x, &obj.vecScale.y, 
			&obj.rotation,
			&obj.color,
			&obj.ObjectStyle, &data1.objCount);

		///////////////////////////////////Read ObjectStyle and assign each texture
		if (obj.rotation <= 4&&obj.rotation >0)
			obj.rotation = 180;
		switch (obj.ObjectStyle)
		{
		case  data1.Square:
			obj.ObjectStyle = data1.Square;
			obj.texture = data1.SquareID;
			data1.SquareMgr->AddObject(obj.vecPos, obj.vecScale,
				obj.rotation, obj.texture, obj.ObjectStyle, obj.color, obj.wVel, obj.vecRef,
				obj.vecGravityChang, obj.vecAngle, obj.fP, obj.fC, obj.fPower,
				obj.fDegree, obj.fCosVal, obj.fSinVal, obj.vecForce, obj.emitterID);
			break;
		case  data1.Cannon:
			obj.ObjectStyle = data1.Cannon;
			obj.texture = data1.CannonID;

			data1.BallMgr->AddObject({ obj.vecPos.x , obj.vecPos.y }, { 5,5 },
				obj.rotation, obj.texture, obj.ObjectStyle, obj.color, obj.wVel, obj.vecRef,
				obj.vecGravityChang, obj.vecAngle, obj.fP, obj.fC,
				obj.fPower, obj.fDegree, obj.fCosVal, obj.fSinVal, obj.vecForce, obj.emitterID);

			data1.CannonMgr->AddObject(obj.vecPos, obj.vecScale,
				obj.rotation, obj.texture, obj.ObjectStyle, obj.color, obj.wVel, obj.vecRef,
				obj.vecGravityChang, obj.vecAngle, obj.fP, obj.fC,
				obj.fPower, obj.fDegree, obj.fCosVal, obj.fSinVal, obj.vecForce, obj.emitterID);
			break;
		case  data1.GravityZone:
			obj.ObjectStyle = data1.GravityZone;
			obj.texture = data1.GravityZoneID;

			data1.GravityzoneMgr->AddObject(obj.vecPos, obj.vecScale,
				obj.rotation, obj.texture, obj.ObjectStyle, obj.color, obj.wVel, obj.vecRef,
				obj.vecGravityChang, obj.vecAngle, obj.fP, obj.fC,
				obj.fPower, obj.fDegree, obj.fCosVal, obj.fSinVal, obj.vecForce, obj.emitterID);
			break;
		case  data1.GravityUp:
			obj.ObjectStyle = data1.GravityZone;
			obj.texture = data1.GravityZoneID;

			data1.GravityzoneMgr->AddObject(obj.vecPos, obj.vecScale,
				obj.rotation, obj.texture, obj.ObjectStyle, obj.color, obj.wVel, obj.vecRef,
				obj.vecGravityChang, obj.vecAngle, obj.fP, obj.fC,
				obj.fPower, obj.fDegree, obj.fCosVal, obj.fSinVal, obj.vecForce, obj.emitterID);
			break;
		case  data1.GravityDown:
			obj.ObjectStyle = data1.GravityZone;
			obj.texture = data1.GravityZoneID;

			data1.GravityzoneMgr->AddObject(obj.vecPos, obj.vecScale,
				obj.rotation, obj.texture, obj.ObjectStyle, obj.color, obj.wVel, obj.vecRef,
				obj.vecGravityChang, obj.vecAngle, obj.fP, obj.fC,
				obj.fPower, obj.fDegree, obj.fCosVal, obj.fSinVal, obj.vecForce, obj.emitterID);
			break;
		case  data1.ClearZone:
			obj.ObjectStyle = data1.ClearZone;
			obj.texture = data1.ClearZoneID;
			data1.ClearZoneObj.vecPos = obj.vecPos;
			data1.ClearZoneObj.vecScale = obj.vecScale;
			break;
		case  data1.Star:
			obj.ObjectStyle = data1.Star;
			obj.texture = data1.StarID;
			data1.StarMgr->AddObject(obj.vecPos, obj.vecScale,
				obj.rotation, obj.texture, obj.ObjectStyle, obj.color, obj.wVel, obj.vecRef,
				obj.vecGravityChang, obj.vecAngle, obj.fP, obj.fC,
				obj.fPower, obj.fDegree, obj.fCosVal, obj.fSinVal, obj.vecForce, obj.emitterID);
			break;
		case  data1.MovingWall:
			obj.ObjectStyle = data1.MovingWall;
			obj.texture = data1.SquareID;
			obj.color = (255, 255, 255, 0);
			data1.MovingWallMgr->AddObject(obj.vecPos, obj.vecScale,
				obj.rotation, obj.texture, obj.ObjectStyle, obj.color, obj.wVel, obj.vecRef,
				obj.vecGravityChang, obj.vecAngle, obj.fP, obj.fC,
				obj.fPower, obj.fDegree, obj.fCosVal, obj.fSinVal, obj.vecForce, obj.emitterID);
			break;
		case  data1.Spine:
			obj.ObjectStyle = data1.Spine;
			obj.texture = data1.SpineID;
			obj.color = (255, 255, 255, 0);
			data1.SpineMgr->AddObject(obj.vecPos, obj.vecScale,
				obj.rotation, obj.texture, obj.ObjectStyle, obj.color, obj.wVel, obj.vecRef,
				obj.vecGravityChang, obj.vecAngle, obj.fP, obj.fC,
				obj.fPower, obj.fDegree, obj.fCosVal, obj.fSinVal, obj.vecForce, obj.emitterID);
			break;
		case  data1.BreakableWall:
			obj.ObjectStyle = data1.BreakableWall;
			obj.texture = data1.BreakableWall0;
			obj.color = (255, 255, 255, 0);
			obj.fSinVal = 3;
			data1.BreakWallMgr->AddObject(obj.vecPos, obj.vecScale,
				obj.rotation, obj.texture, obj.ObjectStyle, obj.color, obj.wVel, obj.vecRef,
				obj.vecGravityChang, obj.vecAngle, obj.fP, obj.fC,
				obj.fPower, obj.fDegree, obj.fCosVal, obj.fSinVal, obj.vecForce, obj.emitterID);
			break;
			
		default:
			WEStateManager::Quit();
		}
	}
	fclose(fp); 
	////////////////////////////////////All Objects will add in the ObjMgr
	Object* MovingWallMgr1 = data1.MovingWallMgr->GetObjects();
	Object* SquareObj1 = data1.SquareMgr->GetObjects();

	for (int i = 0; i<data1.SquareMgr->GetObjectCount() ; i++)
	{
		for (int j = 0; j<data1.MovingWallMgr->GetObjectCount(); j++)
		{
			if (SquareObj1[i].vecPos == MovingWallMgr1[j].vecPos)
			{
				if (MovingWallMgr1[j].rotation == 90)
					SquareObj1[i].wVel.Set(30, 0);
				if (MovingWallMgr1[j].rotation == 0)
					SquareObj1[i].wVel.Set(0, 30);
				if(MovingWallMgr1[j].rotation >0 && MovingWallMgr1[j].rotation<90)
					SquareObj1[i].wVel.Set(-30,30);
				if (MovingWallMgr1[j].rotation >90)
					SquareObj1[i].wVel.Set(30,30);
				SquareObj1[i].Moving = true;
				MovingWallMgr1[j].Movingnum = SquareObj1[i].objectID;				
			}
		}
	}

	
	ScoreCount = 0;
	data1.Check = false;
	data1.WinCheck = false;
	data1.LoseCheck = false;
	data1.PreventR = true;
	data1.SpineCheck = false;
	data1.SpacePressCheck = false;
	data1.OutOfWindow = false;

	WinHeader::WinInit();
	LoseHUDHeader::LoseHUDInit();
	PauseHUDHeader::PauseHUDInit();
	HUDHeader::HUDInit();
	data1.fcameraRot = 0;
	if (!isMusicOn)
		sound.playSound(SOUNDLIST::LEVEL1, true);
	if(!isPlaying)
	sound.pauseMusic(SOUNDLIST::LEVEL1, false);

	//Object Manager 
	SquareObj = data1.SquareMgr->GetObjects();
	BallObj = data1.BallMgr->GetObjects();
	CannonObj = data1.CannonMgr->GetObjects();
	GravityZoneObj = data1.GravityzoneMgr->GetObjects();
	StarObj = data1.StarMgr->GetObjects();
	SpineObj = data1.SpineMgr->GetObjects();
	MovingWallObj = data1.MovingWallMgr->GetObjects();
	BreakableWallObj = data1.BreakWallMgr->GetObjects();
}



/******************************************************************************/
/*!
\brief

Update Objects Position and Movement.
Manage all reaction of objects between objects
\param dt
dt
*/
/******************************************************************************/
void Level1Update(float dt) {
	WEApplication::SetShowCursor(true);
	for (int i = 0; i < 30; i++)
	{
		if (StarObj[i].vecPos.x == 0 && StarObj[i].vecPos.y == 0)
			StarObj[i].vecPos.Set(3000, 3000);
	}

	WEGraphics::SetCamera(0, 0, 60, 0);
	isMusicOn = true;
	isPlaying = true;

	if (WEInput::IsTriggered(WE_V))
	{
		WEGraphics::SetViewport(
			(int)(data1.fwindowWidth*.25f),
			(int)(data1.fwindowHeight*.25f),
			(int)(data1.fwindowWidth *.5f),
			(int)(data1.fwindowHeight*.5f));
		Camera::viewTimer = 0.f;
	}

	if (Camera::viewTimer < WE_MAX_TIME)
	{
		Camera::viewTimer += dt;
		if (Camera::viewTimer > WE_MAX_TIME)
		{
			WEGraphics::SetViewport(0, 0, (int)(data1.fwindowWidth),
				(int)(data1.fwindowHeight));
		}
	}

	WEVec2 mouse;
	WEInput::GetMouse(mouse);
	WEGraphics::ConvertScreenToWorld(mouse.x, mouse.y);
	WEMtx44 transform;
	// Get Objects' Info
	///////////////////DRAW Part
	WEGraphics::SetToPerspective();

	WEVec2 ShootStart;
	WEVec2 ShootEnd;
	WEVec2 vel = { 0,0 };

	if (data1.Check == false)
	{
		for (int i = 0; i < data1.BallMgr->GetObjectCount(); ++i)
		{
			Physics::DGravity(&BallObj[i], { 0,-40 });

			ShootStart = { CannonObj[0].vecPos.x, CannonObj[0].vecPos.y };
			ShootEnd = { CannonObj[0].vecPos.x + 1.0f, CannonObj[0].vecPos.y - 2.0f };

			Shoot::ChangeDegree(&BallObj[i]);

			WEVec2 Ballpos;
			Ballpos.Set(BallObj[i].vecPos.x + 2.f, BallObj[i].vecPos.y + 2.f);
			Collision::CannonBall(&BallObj[i], &CannonObj[0]);

			if (WEInput::IsTriggered(WE_R) && data1.PreventR == false && !data1.SpacePressCheck)
			{
				data1.SpineCheck = false;
				data1.PreventR = true;
			}
			WEGraphics::SetToPerspective();/*Draw in world space*/

			if (WEInput::IsPressed(WE_SPACE))
			{
				data1.SpacePressCheck = true;
				data1.PreventR = false;
			}
			else
				data1.SpacePressCheck = false;

			// Ball can shoot with cannon
			if (WEIntersection::CircleLine(Ballpos, BallObj[i].vecScale.x *.5f,
				ShootStart, ShootEnd)) {
				Shoot::ShootBall(&BallObj[i], &sound, SOUNDLIST::SHOOT);

			}

			if (BallObj[i].vecPos.x <= CannonObj[i].vecPos.x + 5 && BallObj[i].vecPos.x >= CannonObj[i].vecPos.x - 5 &&
				BallObj[i].vecPos.y <= CannonObj[i].vecPos.y + 5 && BallObj[i].vecPos.y >= CannonObj[i].vecPos.y - 5)
			{
				data1.SpacePressCheck = false;
				CheckForFalseHUD();
			}
			else
			{
				data1.SpacePressCheck = true;
				CheckForTrueHUD();
			}

			for (int j = 0; j < data1.GravityzoneMgr->GetObjectCount(); ++j)
			{
				if (WEIntersection::CircleRect(BallObj[0].vecPos, BallObj[0].vecScale.x *.5f, GravityZoneObj[j].vecPos, GravityZoneObj[j].vecScale.x, GravityZoneObj[j].vecScale.y))
				{
					if (GravityZoneObj[j].rotation == 180)
						Physics::UGravity(&BallObj[0], { 250,0 }); // Right 

					if (GravityZoneObj[j].rotation == 0)
						Physics::UGravity(&BallObj[0], { -250,0 }); // Left 

					if (GravityZoneObj[j].rotation == 90)
						Physics::UGravity(&BallObj[0], { 0,-250 }); // Down 

					if (GravityZoneObj[j].rotation == 270)
						Physics::UGravity(&BallObj[0], { 0,250 }); // Upper Gravity
				}
			}
			Physics::ChangingVel(&BallObj[i], dt);
			Physics::ChangingPos(&BallObj[i], dt);
			Physics::ResetGravity(&BallObj[i]);

			for (int j = 0; j < data1.SquareMgr->GetObjectCount(); ++j)
			{
				Collision::RecBall(&BallObj[i], &SquareObj[j], sound, SOUNDLIST::BOUNCING);
			}

			for (int j = 0; j < data1.BreakWallMgr->GetObjectCount(); ++j)
				Collision::RecBall(&BallObj[i], &BreakableWallObj[j], sound, SOUNDLIST::BOUNCING);

			for (int p = 0; p < data1.BreakWallMgr->GetObjectCount(); ++p)
			{
				if (WEIntersection::CircleRect(BallObj[0].vecPos, BallObj[0].vecScale.x *.5f, BreakableWallObj[p].vecPos
					, BreakableWallObj[p].vecScale.x, BreakableWallObj[p].vecScale.y))
					BreakableWallObj[p].fSinVal -= 1;

				if (BreakableWallObj[p].fSinVal == 0)
				{
					BreakableWallObj[p].vecPos.Set(3000, 3000);
					BreakableWallObj[p].vecScale.Set(0, 0);
				}
			}
		}// for roop end

		WEGraphics::StartDraw();

		WEGraphics::SetToOrtho();

		if (!(LevelStage == 30))
			WEGraphics::SetTexture(backgroundTex);
		else
			WEGraphics::SetTexture(data1.FianlBack);
		WEGraphics::SetTextureColor(255, 255, 255, 255);
		WEGraphics::SetTextureCoords(1.0f, 1.0f, 0.0f, 1.0f, 1.0f);
		transform.MakeTransform(transform, data1.fwindowWidth, data1.fwindowHeight, 0.0f,
			data1.fwindowWidth*.5f, data1.fwindowHeight*.5f, -1.0f);
		WEGraphics::Draw(transform);

		if (LevelSelect == 1)
		{
			WEMtx44 ins;
			WEGraphics::SetToPerspective();
			WEGraphics::SetTexture(data1.ins0ID);
			WEGraphics::SetTextureColor(255, 255, 255, 255);
			WEGraphics::SetTextureCoords(.02f, 1.0f, 0.0f, texturecoord4, 0.0f);
			WEMtx44::MakeTransform(ins, 70, 40,
				0.0f, -20, -30, 1.0f);
			WEGraphics::Draw(ins);
			WEMtx44 ins0;

			WEGraphics::SetToPerspective();
			WEGraphics::SetTexture(data1.ins1ID);
			WEGraphics::SetTextureColor(255, 255, 255, 255);
			WEGraphics::SetTextureCoords(1.f, 1.0f, 0.0f, 1.f, 0.0f);
			WEMtx44::MakeTransform(ins0, 100, 60, 0.0f,
				60, -40, 1.0f);
			WEGraphics::Draw(ins0);
			WEGraphics::SetToPerspective();
		}

		if (LevelSelect == 2)
		{
			WEMtx44 Reflect;
			WEGraphics::SetToPerspective();
			WEGraphics::SetTexture(ReflectAni);
			WEGraphics::SetTextureColor(255, 255, 255, 255);
			WEGraphics::SetTextureCoords(.05f, 1.0f, 0.0f, texturecoord5, 0.0f);
			WEMtx44::MakeTransform(Reflect, 70, 40,
				0.0f, 50, -30, 1.0f);
			WEGraphics::Draw(Reflect);

			WEGraphics::SetTextureCoords(1.f, 1.0f, 0.0f, 1.f, 0.0f);
		}
		WEGraphics::SetTextureColor(0xFFF00FFF);
		WEMtx44 Square;
		WEMtx44 Ball;
		WEMtx44 Cannon;
		WEMtx44 Star;
		WEMtx44 Spine;

		/*When clear level, PauseHUD pop up*/
		if (LevelSelect != 30)
		{
			if (!data1.SpineCheck)
			{
				if (WEIntersection::CircleCircle(BallObj[0].vecPos, BallObj[0].vecScale.x *.5f, data1.ClearZoneObj.vecPos, data1.ClearZoneObj.vecScale.x * 0.5f) || WEInput::IsTriggered(WE_F1)) {
					for (int a = 1; a < 30; a++)
						if (LevelSelect == a)
							if (ClearLevel <= LevelSelect)
							{
								ClearLevel = a + 1;
							}

					if (GetStar[LevelSelect - 1] >= 3)
						GetStar[LevelSelect - 1] = 3;

					else if (GetStar[LevelSelect - 1] < 3)
						GetStar[LevelSelect - 1] = ScoreCount;

					sound.playSound(SOUNDLIST::STAR, false);
					WinHeader::WinUpdate(dt);
					data1.WinCheck = true;
					data1.Check = true;
				}
			}
		}

		if (LevelSelect == 30)
		{
			if (!data1.SpineCheck)
			{
				if (WEIntersection::CircleCircle(BallObj[0].vecPos, BallObj[0].vecScale.x *.5f, data1.ClearZoneObj.vecPos, data1.ClearZoneObj.vecScale.x *.5f))
				{
					sound.playSound(SOUNDLIST::STAR, false);
					EndingHeader::EndingUpdate(dt);
					BallObj[0].vecPos = data1.ClearZoneObj.vecPos;
				}
			}

		}

		/*Star React*/
		for (int l = 0; l < 30; l++)
		{
			if (WEIntersection::CircleRect(BallObj[0].vecPos, BallObj[0].vecScale.x *.5f, StarObj[l].vecPos, StarObj[l].vecScale.x, StarObj[l].vecScale.y))
			{
				sound.playSound(SOUNDLIST::STAR, false);
				StarObj[l].vecPos = { -1000,-1000 };
				ScoreCount++;
			}
		}

		/*Spine React*/
		for (int i = 0; i < data1.SpineMgr->GetObjectCount(); ++i)
			if (WEIntersection::CircleRect(BallObj[0].vecPos, BallObj[0].vecScale.x *.5f, SpineObj[i].vecPos, SpineObj[i].vecScale.x, SpineObj[i].vecScale.y))
				if (data1.SpineCheck == false)
					data1.SpineCheck = true;

		if (data1.SpineCheck)
			BallObj[0].vecPos.Set(10000, 10000);

		/*If ball is out of window*/
		if (BallObj[0].vecPos.x < -WINDOW_X || BallObj[0].vecPos.x > WINDOW_X ||
			BallObj[0].vecPos.y < -WINDOW_Y || BallObj[0].vecPos.y > WINDOW_Y)
		{
			data1.OutOfWindow = true;

			CheckBallPosition();
		}

		if (SendLife() < -1)
		{
			GetStar[LevelSelect] = 0;
			LoseHUDHeader::LoseHUDUpdate(dt);
			sound.playSound(SOUNDLIST::LOSE, false);
			data1.LoseCheck = true;
			data1.Check = true;
		}

		//Breakable Wall Drawing
		WEMtx44 BW;

		for (int i = 0; i < data1.BreakWallMgr->GetObjectCount(); ++i)
		{
			WEGraphics::SetToPerspective();
			WEGraphics::SetTextureColor(255, 255, 255, 255);
			WEGraphics::SetTexture(data1.BreakableWall0);
			if (BreakableWallObj[i].fSinVal == 3)
				WEGraphics::SetTexture(data1.BreakableWall0);
			if (BreakableWallObj[i].fSinVal == 2)
				WEGraphics::SetTexture(data1.BreakableWall1);
			if (BreakableWallObj[i].fSinVal == 1)
				WEGraphics::SetTexture(data1.BreakableWall2);

			WEMtx44::MakeTransform(BW,
				BreakableWallObj[i].vecScale.x, BreakableWallObj[i].vecScale.y,
				BreakableWallObj[i].rotation,
				BreakableWallObj[i].vecPos.x, BreakableWallObj[i].vecPos.y, -1.f);
			WEGraphics::Draw(BW);
		}

		//Applying Moving Wall
		for (int i = 0; i < data1.MovingWallMgr->GetObjectCount(); ++i)
		{
			if (MovingWallObj[i].rotation == 0)
			{
				if (SquareObj[MovingWallObj[i].Movingnum].vecPos.y
					>= MovingWallObj[i].vecPos.y + (MovingWallObj[i].vecScale.y *.5f))
					SquareObj[MovingWallObj[i].Movingnum].wVel.Set(0, -30);

				else if (SquareObj[MovingWallObj[i].Movingnum].vecPos.y
					< MovingWallObj[i].vecPos.y - (MovingWallObj[i].vecScale.y *.5f))
					SquareObj[MovingWallObj[i].Movingnum].wVel.Set(0, 30);
			}

			if (MovingWallObj[i].rotation == 90)
			{
				if (SquareObj[MovingWallObj[i].Movingnum].vecPos.x
					>= MovingWallObj[i].vecPos.x + (MovingWallObj[i].vecScale.x *.5f))
					SquareObj[MovingWallObj[i].Movingnum].wVel.Set(-30, 0);

				else if (SquareObj[MovingWallObj[i].Movingnum].vecPos.x
					< MovingWallObj[i].vecPos.x - (MovingWallObj[i].vecScale.x *.5f))
					SquareObj[MovingWallObj[i].Movingnum].wVel.Set(30, 0);
			}

			if (MovingWallObj[i].rotation > 90)
			{
				if (SquareObj[MovingWallObj[i].Movingnum].vecPos.x
					< MovingWallObj[i].vecPos.x - (MovingWallObj[i].vecScale.y *.5f))
					SquareObj[MovingWallObj[i].Movingnum].wVel.Set(30, 30);

				else if (SquareObj[MovingWallObj[i].Movingnum].vecPos.x
					>= MovingWallObj[i].vecPos.x + (MovingWallObj[i].vecScale.y *.5f))
					SquareObj[MovingWallObj[i].Movingnum].wVel.Set(-30, -30);
			}

			if (MovingWallObj[i].rotation > 0 && MovingWallObj[i].rotation < 90)
			{
				if (SquareObj[MovingWallObj[i].Movingnum].vecPos.x
					< MovingWallObj[i].vecPos.x - (MovingWallObj[i].vecScale.y *.5f))
					SquareObj[MovingWallObj[i].Movingnum].wVel.Set(30, -30);

				else if (SquareObj[MovingWallObj[i].Movingnum].vecPos.x
					>= MovingWallObj[i].vecPos.x + (MovingWallObj[i].vecScale.y *.5f))
					SquareObj[MovingWallObj[i].Movingnum].wVel.Set(-30, 30);
			}
		}

		if (data1.SpineCheck == false)
		{
			Shoots = false;
			//Draw Ball
			for (int i = 0; i < data1.BallMgr->GetObjectCount(); ++i)
			{
				WEGraphics::SetToPerspective();
				WEGraphics::SetTextureColor(255, 255, 255, 255);
				WEGraphics::SetTexture(data1.BallID);
				WEMtx44::MakeTransform(Ball,
					BallObj[i].vecScale.x, BallObj[i].vecScale.y,
					WEMath::DegreeToRadian(BallObj[i].fDegree),
					BallObj[i].vecPos.x, BallObj[i].vecPos.y, -1.f);
				WEGraphics::Draw(Ball);
			}
		}

		//Drawing Square
		for (int i = 0; i < data1.SquareMgr->GetObjectCount(); ++i)
		{
			Physics::ChangingPos(&SquareObj[i], dt);

			WEGraphics::SetToPerspective();
			WEGraphics::SetTextureColor(255, 255, 255, 255);
			WEGraphics::SetTexture(data1.SquareID);
			WEMtx44::MakeTransform(Square,
				SquareObj[i].vecScale.x, SquareObj[i].vecScale.y,
				WEMath::DegreeToRadian(SquareObj[i].rotation),
				SquareObj[i].vecPos.x, SquareObj[i].vecPos.y, 1.f);

			WEGraphics::Draw(Square);
		}

		// Draw Spine
		for (int i = 0; i < data1.SpineMgr->GetObjectCount(); ++i)
		{
			WEGraphics::SetToPerspective();
			WEGraphics::SetTextureColor(255, 255, 255, 255);
			WEGraphics::SetTexture(data1.SpineID);
			WEMtx44::MakeTransform(Spine,
				SpineObj[i].vecScale.x, SpineObj[i].vecScale.y,
				WEMath::DegreeToRadian(SpineObj[i].rotation),
				SpineObj[i].vecPos.x, SpineObj[i].vecPos.y, -1.f);
			WEGraphics::Draw(Spine);
		}

		if (WEIntersection::CircleRect(BallObj[0].vecPos, BallObj[0].vecScale.x *.5f, CannonObj[0].vecPos, CannonObj[0].vecScale.x, CannonObj[0].vecScale.y))
			Shoots = true;

		if (WEInput::IsTriggered(WE_R) || data1.OutOfWindow || data1.SpineCheck)
		{
			BallObj[0].vecForce.Set(0, 0);
			BallObj[0].wVel.Set(0, 0);
			BallObj[0].vecPos.x = CannonObj[0].vecPos.x;
			BallObj[0].vecPos.y = CannonObj[0].vecPos.y - 0.5f;
			data1.SpineCheck = false;
			data1.OutOfWindow = false;
			Shoots = true;
			sound.playSound(SOUNDLIST::RELOADING, false);
		}

		//Drawing R key
		WEMtx44 R;

		for (int i = 0; i < data1.CannonMgr->GetObjectCount(); ++i)
		{
			WEGraphics::SetTextureColor(255, 255, 255, 255);
			if (Shoots)
			{
				WEGraphics::SetTexture(data1.FullcannonID);
				WEMtx44::MakeTransform(Cannon,
					CannonObj[i].vecScale.x + 3, CannonObj[i].vecScale.y + 3,
					WEMath::DegreeToRadian(BallObj[i].fDegree), CannonObj[i].vecPos.x, CannonObj[i].vecPos.y, 1.f);
				WEGraphics::Draw(Cannon);
			}

			else
			{
				WEGraphics::SetToPerspective();
				WEGraphics::SetTextureColor(255, 255, 255, 255);

				WEGraphics::SetTexture(ResetBarTex);
				WEGraphics::SetTextureCoords(.5f, 1.0f, 0.0f, texturecoord, 0.0f);
				WEMtx44::MakeTransform(R,
					11, 11,
					0,
					CannonObj[0].vecPos.x, CannonObj[0].vecPos.y + 14, 3.f);
				WEGraphics::Draw(R);

				WEGraphics::SetTextureCoords(1.f, 1.0f, 0.0f, 1.f, 0.0f);
				WEGraphics::SetTexture(data1.CannonID);
				WEMtx44::MakeTransform(Cannon,
					CannonObj[i].vecScale.x, CannonObj[i].vecScale.y,
					WEMath::DegreeToRadian(BallObj[i].fDegree), CannonObj[i].vecPos.x, CannonObj[i].vecPos.y, 1.f);
				WEGraphics::Draw(Cannon);
			}
		}

		timecount += dt;

		if (WEInput::IsPressed(WE_ARROW_UP))
		{
			input = false;
			texturecoord = .5f;
		}

		if (WEInput::IsPressed(WE_ARROW_DOWN))
		{
			input = false;
			texturecoord2 = .5f;
		}

		if (WEInput::IsPressed(WE_SPACE))
		{
			input = false;
			texturecoord3 = .5f;
		}

		if (input)
		{
			if (timecount > 0.5f)
			{
				timecount = 0.0f;
				texturecoord = 0.0f;
				texturecoord2 = 0.0f;
				texturecoord3 = 0.0f;
				WEMath::Wrap(texturecoord, 0.0f, 1.0f);
			}
		}

		if (timecount > 0.1f)
		{
			timecount = 0.0f;
			texturecoord4 += 0.02f;
			WEMath::Wrap(texturecoord, 0.0f, 1.0f);

		}

		timecount1 += dt;

		if (timecount1 > 0.1f)
		{
			timecount1 = 0.0f;
			texturecoord5 += .05f;
			WEMath::Wrap(texturecoord5, 0.0f, 1.0f);
		}

		input = true;

		Shoot::DrawLine(&BallObj[0], &CannonObj[0]);

		HUDHeader::HUDUpdate(dt);

		//clearZone
		WEMtx44 ClearZone;
		static float clearRai = 0.f;
		clearRai -= dt * Clear_Speed;
		if (!(LevelSelect == 30))
			WEGraphics::SetTexture(data1.ClearZoneID);
		else
			WEGraphics::SetTexture(data1.earth);

		WEGraphics::SetTextureColor(255, 255, 255, 255);

		if (LevelSelect == 30)
			clearRai = 0;

		WEMtx44::MakeTransform(ClearZone,
			data1.ClearZoneObj.vecScale.x, data1.ClearZoneObj.vecScale.y, clearRai,
			data1.ClearZoneObj.vecPos.x, data1.ClearZoneObj.vecPos.y, 1.f);
		WEGraphics::Draw(ClearZone);

		WEMtx44 Cannontri;
		WEGraphics::SetTexture(data1.CannonTriID);
		WEGraphics::SetTextureColor(255, 255, 255, 255);
		WEGraphics::SetTextureCoords(1.0f, 1.0f, 0.0f, 1.0f, 1.0f);
		WEMtx44::MakeTransform(Cannontri, 10, 5,
			0, CannonObj[0].vecPos.x, CannonObj[0].vecPos.y - 6, 2.f);

		WEGraphics::Draw(Cannontri);
		WEGraphics::SetToPerspective();
		WEMtx44 GravityArrow;

		for (int i = 0; i < data1.GravityzoneMgr->GetObjectCount(); ++i)
		{
			WEGraphics::SetTexture(data1.GravityZoneID);
			WEGraphics::SetTextureColor(255, 255, 255, 125);
			WEGraphics::SetTextureCoords(1.0f, 1.0f, 0.0f, 1.0f, 1.0f);
			WEMtx44::MakeTransform(transform,
				GravityZoneObj[i].vecScale.x, GravityZoneObj[i].vecScale.y,
				0,
				GravityZoneObj[i].vecPos.x, GravityZoneObj[i].vecPos.y, -4.f);
			WEGraphics::Draw(transform);

			WEGraphics::SetTexture(data1.BackSignTexture);
			WEGraphics::SetTextureColor(255, 255, 255, 255);
			WEMtx44::MakeTransform(GravityArrow,
				8, 8,
				WEMath::DegreeToRadian(GravityZoneObj[i].rotation),
				GravityZoneObj[i].vecPos.x, GravityZoneObj[i].vecPos.y, 2.f);

			WEGraphics::Draw(GravityArrow);
		}

		//Draw Stars
		for (int i = 0; i < data1.StarMgr->GetObjectCount(); ++i)
		{
			WEGraphics::SetTextureColor(255, 255, 255, 255);
			WEGraphics::SetTexture(data1.StarID);
			WEMtx44::MakeTransform(Star,
				StarObj[i].vecScale.x, StarObj[i].vecScale.y,
				0, StarObj[i].vecPos.x, StarObj[i].vecPos.y, 1.f);

			WEGraphics::Draw(Star);
		}
	}//if

	else if (data1.Check == true && data1.WinCheck == false && data1.LoseCheck == false)
	{
		PauseHUDHeader::PauseHUDUpdate(dt);

	}

	if (data1.WinCheck == true && data1.LoseCheck == false && (LevelSelect != 30))
		WinHeader::WinUpdate(dt);

	if (data1.LoseCheck == true && data1.WinCheck == false)
		LoseHUDHeader::LoseHUDUpdate(dt);

	if (data1.WinCheck == false && data1.LoseCheck == false)
	{		
		if (WEInput::IsTriggered(WE_ESCAPE) && data1.Check == true)
			data1.Check = false;

		else if (WEInput::IsTriggered(WE_ESCAPE) && data1.Check == false)
		{
			PauseHUDHeader::PauseHUDUpdate(dt);
			data1.Check = true;
		}
	}


	if (LevelStage<11)
	{
		WEGraphics::SetToOrtho();
		WEGraphics::SetTexture(StageLevelTex);
		WEGraphics::SetTextureColor(255, 255, 255, 128);

		for (int i = 0; i < LEVEL_MAX; ++i)
		{
			Button * pLevel = &data1.button[LevelStage - 1];
			WEGraphics::SetTextureCoords(.1f, 1.0f, 0.0f, pLevel->texPos.x, 1.0f);
			transform.MakeTransform(transform, LEVEL_X*.5f, LEVEL_Y*.5f, 0.0f,
				data1.fwindowWidth*.5f, data1.fwindowHeight - LEVEL_Y*.25f, 1.0f);
		}
		WEGraphics::Draw(transform);
	}

	else if (LevelStage<21)
	{
		WEGraphics::SetToOrtho();
		WEGraphics::SetTexture(StageLevelTex2);
		WEGraphics::SetTextureColor(255, 255, 255, 128);
		for (int i = 0; i < LEVEL_MAX; ++i)
		{
			Button * pLevel = &data1.button[LevelStage - 11];
			WEGraphics::SetTextureCoords(.1f, 1.0f, 0.0f, pLevel->texPos.x, 1.0f);
			transform.MakeTransform(transform, LEVEL_X*.5f, LEVEL_Y*.5f, 0.0f,
				data1.fwindowWidth*.5f, data1.fwindowHeight - LEVEL_Y*.25f, 1.0f);
		}
		WEGraphics::Draw(transform);
	}

	else if (LevelStage < 31)
	{
		WEGraphics::SetToOrtho();
		WEGraphics::SetTexture(StageLevelTex3);
		WEGraphics::SetTextureColor(255, 255, 255, 128);
		for (int i = 0; i < LEVEL_MAX; ++i)
		{
			Button * pLevel = &data1.button[LevelStage - 21];
			WEGraphics::SetTextureCoords(.1f, 1.0f, 0.0f, pLevel->texPos.x, 1.0f);
			transform.MakeTransform(transform, LEVEL_X*.5f, LEVEL_Y*.5f, 0.0f,
				data1.fwindowWidth*.5f, data1.fwindowHeight - LEVEL_Y*.25f, 1.0f);
		}
		WEGraphics::Draw(transform);
	}

	WEGraphics::EndDraw();
}
/******************************************************************************/
/*!
\brief
Checking the level and load its level from the txt file

\param  level
the level which is clicked by users on the level select stage
*/
/******************************************************************************/
void F_levelSelect(int Level)
{

	switch (Level)
	{
	case 1:
		LevelName = path;
		LevelName += "Levels/Level1.txt";
		LevelStage = 1;
		break;
	case 2:
		LevelName = path;
		LevelName += "Levels/Level2.txt";
		LevelStage = 2;
		break;
	case 3:
		LevelName = path;
		LevelName += "Levels/Level3.txt";
		LevelStage = 3;
		break;
	case 4:
		LevelName = path;
		LevelName = path+ "Levels/Level4.txt";
		LevelStage = 4;
		break;
	case 5:
		LevelName = path+ "Levels/Level5.txt";
		LevelStage = 5;
		break;
	case 6:
		LevelName = path+ "Levels/Level6.txt";
		LevelStage = 6;
		break;
	case 7:
		LevelName = path+ "Levels/Level7.txt";
		LevelStage = 7;
		break;
	case 8:
		LevelName = path+ "Levels/Level8.txt";
		LevelStage = 8;
		break;
	case 9:
		LevelName = path+ "Levels/Level9.txt";
		LevelStage = 9;
		break;
	case 10:
		LevelName = path+ "Levels/Level10.txt";
		LevelStage = 10;
		break;
	case 11:
		LevelName = path+ "Levels/Level11.txt";
		LevelStage = 11;
		break;

	case 12:
		LevelName = path+ "Levels/Level12.txt";
		LevelStage = 12;
		break;
	case 13:
		LevelName = path+ "Levels/Level13.txt";
		LevelStage = 13;
		break;
	case 14:
		LevelName = path+ "Levels/Level14.txt";
		LevelStage = 14;
		break;
	case 15:
		LevelName = path+ "Levels/Level15.txt";
		LevelStage = 15;
		break;
	case 16:
		LevelName = path+ "Levels/Level16.txt";
		LevelStage = 16;
		break;
	case 17:
		LevelName = path+ "Levels/Level17.txt";
		LevelStage = 17;
		break;
	case 18:
		LevelName = path+ "Levels/Level18.txt";
		LevelStage = 18;
		break;
	case 19:
		LevelName = path+ "Levels/Level19.txt";
		LevelStage = 19;
		break;
	case 20:
		LevelName = path+ "Levels/Level20.txt";
		LevelStage = 20;
		break;
	case 21:
		LevelName = path+ "Levels/Level21.txt";
		LevelStage = 21;
		break;
	case 22:
		LevelName = path+ "Levels/Level22.txt";
		LevelStage = 22;
		break;
	case 23:
		LevelName = path+ "Levels/Level23.txt";
		LevelStage = 23;
		break;
	case 24:
		LevelName = path+ "Levels/Level24.txt";
		LevelStage = 24;
		break;
	case 25:
		LevelName = path+ "Levels/Level25.txt";
		LevelStage = 25;
		break;
	case 26:
		LevelName = path+ "Levels/Level26.txt";
		LevelStage = 26;
		break;
	case 27:
		LevelName = path+ "Levels/Level27.txt";
		LevelStage = 27;
		break;
	case 28:
		LevelName = path+ "Levels/Level28.txt";
		LevelStage = 28;
		break;
	case 29:
		LevelName = path+ "Levels/Level29.txt";
		LevelStage = 29;
		break;
	case 30:
		LevelName = path+ "Levels/Level30.txt";
		LevelStage = 30;
		break;
	default:
		WEStateManager::Quit();
	}
}

/******************************************************************************/
/*!
	\brief
		Save Game Data in the text file such as the number of star
		which player got and the number of levels player cleard
*/
/******************************************************************************/
void LevelSaving(void){
	//path += "/Documents/OutandIn/";
	FILE *fp = 0;
	Firststart = 0;
	std::string name = path + "SaveData.txt";
	fopen_s(&fp, name.c_str(), "wt");
	fprintf(fp, "%d %d\n", ClearLevel, Firststart);

	for (int i = 0; i < 30; i++)
		fprintf(fp, "%d\n", GetStar[i]);
	fclose(fp);
}

/******************************************************************************/
/*!
	\brief
		Deallocate all object manager
*/
/******************************************************************************/
void Level1Shutdown(void){	
	delete data1.BallMgr;
	delete data1.SquareMgr;
	delete data1.CannonMgr;
	delete data1.GravityzoneMgr;
	delete data1.StarMgr;
	delete data1.MovingWallMgr;
	delete data1.BreakWallMgr;
	delete data1.SpineMgr;
	LevelSaving();
}

/******************************************************************************/
/*!
	\brief
		Unload all things to prevent memory leak.
*/
/******************************************************************************/
void Level1Unload(void){
	isMusicOn = true;
	WinHeader::WinUnload();
	EndingHeader::EndingUnload();
	LoseHUDHeader::LoseHUDUnload();
	HUDHeader::HUDUnload();
	PauseHUDHeader::PauseHUDUnload();

	WEGraphics::UnloadTexture(data1.earth);
	WEGraphics::UnloadTexture(data1.SquareID);
	WEGraphics::UnloadTexture(data1.BallID);
	WEGraphics::UnloadTexture(data1.CannonID);
	WEGraphics::UnloadTexture(data1.BackSignTexture);
	WEGraphics::UnloadTexture(data1.ClearZoneID);
	WEGraphics::UnloadTexture(data1.SpineID);
	WEGraphics::UnloadTexture(data1.CannonTriID);
	WEGraphics::UnloadTexture(data1.GravityZoneID);
	WEGraphics::UnloadTexture(data1.StarID);
	WEGraphics::UnloadTexture(UpArrowTex);
	WEGraphics::UnloadTexture(DownArrowTex);
	WEGraphics::UnloadTexture(SpaceBarTex);
	WEGraphics::UnloadTexture(ResetBarTex);
	WEGraphics::UnloadTexture(data1.FullcannonID);
	WEGraphics::UnloadTexture(data1.UpID);
	WEGraphics::UnloadTexture(data1.DownID);

	WEGraphics::UnloadTexture(data1.ins0ID);
	WEGraphics::UnloadTexture(data1.ins1ID);
	WEGraphics::UnloadTexture(data1.SpaceID);
	WEGraphics::UnloadTexture(backgroundTex);
	WEGraphics::UnloadTexture(StageLevelTex);
	WEGraphics::UnloadTexture(StageLevelTex2);
	WEGraphics::UnloadTexture(StageLevelTex3);
	WEGraphics::UnloadTexture(data1.FianlBack);
	WEGraphics::UnloadTexture(data1.BreakableWall0);
	WEGraphics::UnloadTexture(data1.BreakableWall1);
	WEGraphics::UnloadTexture(data1.BreakableWall2);
	sound.releaseSound(SOUNDLIST::BOUNCING);
	sound.releaseSound(SOUNDLIST::SHOOT);
	sound.releaseSound(SOUNDLIST::STAR);
	sound.releaseSound(SOUNDLIST::RELOADING);
	sound.pauseMusic(SOUNDLIST::LEVEL1, isMusicOn);
	sound.releaseSound(SOUNDLIST::LOSE);
	WEGraphics::UnloadTexture(ReflectAni);
	isPlaying = false;
}