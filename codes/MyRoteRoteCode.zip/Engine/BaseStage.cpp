/******************************************************************************/
/*!
\file   BaseStage.cpp
\author Choi Beom Geun
\par    email: o77151@gmail.com
\par    Class:GAM250
\par    Thumbup Engine
\date   2017/11/29

BaseStage for the level

*/
/******************************************************************************/

#include "BaseStage.h"

BaseStage::BaseStage(void)
{	
}

BaseStage::~BaseStage(void)
{
}